#!/usr/bin/env python3
"""Independent APK v2 digest/signature and ZIP/native alignment verification."""
import argparse
import hashlib
from pathlib import Path
import struct
import zipfile
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

def u32(data, offset=0):
    return struct.unpack_from('<I', data, offset)[0]

def sequence(data):
    offset = 0
    while offset < len(data):
        size = u32(data, offset)
        offset += 4
        assert offset + size <= len(data), 'Invalid length-prefixed sequence'
        yield data[offset:offset + size]
        offset += size
    assert offset == len(data)

def verify(path, alignment=4096, expected_certificate=None):
    data = Path(path).read_bytes()
    end = data.rfind(b'PK\x05\x06')
    assert end >= 0 and end + 22 + struct.unpack_from('<H', data, end + 20)[0] == len(data)
    central = u32(data, end + 16)
    assert central + u32(data, end + 12) == end
    assert data[central - 16:central] == b'APK Sig Block 42'
    size = struct.unpack_from('<Q', data, central - 24)[0]
    start = central - size - 8
    assert start >= 0 and struct.unpack_from('<Q', data, start)[0] == size
    offset = start + 8
    v2 = None
    while offset < central - 24:
        length = struct.unpack_from('<Q', data, offset)[0]
        assert length >= 4 and offset + 8 + length <= central - 24
        if u32(data, offset + 8) == 0x7109871A:
            assert v2 is None
            v2 = data[offset + 12:offset + 8 + length]
        offset += 8 + length
    assert offset == central - 24 and v2 is not None
    signers, = sequence(v2)
    signer, = sequence(signers)
    signed, signatures, public = sequence(signer)
    digests, certificates, attributes = sequence(signed)
    signature, = sequence(signatures)
    digest_record, = sequence(digests)
    assert u32(signature) == u32(digest_record) == 0x0103
    signature_bytes, = sequence(signature[4:])
    expected_digest, = sequence(digest_record[4:])
    cert_der = next(sequence(certificates))
    if expected_certificate is not None:
        assert cert_der == expected_certificate, 'Signing certificate changed'
    cert = x509.load_der_x509_certificate(cert_der)
    key = serialization.load_der_public_key(public)
    assert cert.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo) == public
    key.verify(signature_bytes, signed, padding.PKCS1v15(), hashes.SHA256())
    eocd = bytearray(data[end:])
    struct.pack_into('<I', eocd, 16, start)
    chunks = []
    for section in (data[:start], data[central:end], eocd):
        for offset in range(0, len(section), 1024 * 1024):
            chunk = section[offset:offset + 1024 * 1024]
            chunks.append(hashlib.sha256(b'\xa5' + struct.pack('<I', len(chunk)) + chunk).digest())
    actual = hashlib.sha256(b'\x5a' + struct.pack('<I', len(chunks)) + b''.join(chunks)).digest()
    assert actual == expected_digest, 'APK content digest mismatch'
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        for entry in archive.infolist():
            if not entry.filename.startswith('lib/'):
                continue
            name_len, extra_len = struct.unpack_from('<HH', data, entry.header_offset + 26)
            payload = entry.header_offset + 30 + name_len + extra_len
            assert entry.compress_type == zipfile.ZIP_STORED and payload % alignment == 0
            elf = archive.read(entry)
            assert elf[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', elf, 18)[0] == 183
    return hashlib.sha256(data).hexdigest()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('apk')
    parser.add_argument('--alignment', type=int, default=4096)
    args = parser.parse_args()
    print('APK v2 signature, content digest, ARM64 ELF and ZIP alignment: OK') if verify(args.apk, args.alignment) else None
