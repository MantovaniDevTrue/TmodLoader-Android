from pathlib import Path
import subprocess, zipfile, struct, hashlib, shutil
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography import x509
from verify_native import verify_native
from verify_apk import verify

ROOT = Path(__file__).resolve().parent
APKDIR = ROOT / 'apk_base'
C = ROOT / 'bootstrap.c'
LIBMAIN = ROOT / 'libmain_phase2_22_98.so'
UNSIGNED = ROOT / 'Phase2_22_98_unsigned.apk'
SIGNED = ROOT / 'tML_Android_Phase2_22_98_PostTextureLoadContentIsolation.apk'
KEY = ROOT / 'phase2226_test_signing_key.pem'
CERT = ROOT / 'phase2226_test_signing_cert.der'
STUBS = ROOT / 'stubs_build'
STUBS.mkdir(exist_ok=True)

clang = shutil.which('clang')
if not clang:
    raise SystemExit('clang not found')
base = [clang, '--target=aarch64-linux-android24', '-fuse-ld=lld', '-nostdinc', '-nostdlib']
imports = {
    'libc.so': ['fopen','fgets','fread','fwrite','fclose','ferror','fgetc','rename','remove','snprintf','strlen','strcmp','mkdir','chdir','memset','strdup','setenv','mprotect','getpagesize','pthread_attr_init','pthread_attr_setstacksize','pthread_attr_destroy','pthread_create','pthread_join'],
    'libdl.so': ['dlopen','dlsym','dlclose','dlerror'],
    'libSDL2.so': ['SDL_AndroidGetInternalStoragePath','SDL_ShowSimpleMessageBox'],
}
for lib, symbols in imports.items():
    src = STUBS / (lib + '.c')
    src.write_text(''.join('void ' + s + '(void) {}\n' for s in symbols))
    subprocess.run(base + ['-shared', '-Wl,-soname,' + lib, str(src), '-o', str(STUBS / lib)], check=True)
subprocess.run(base + ['-shared','-Wl,-soname,libmain.so','-Wl,-z,max-page-size=16384','-Wl,-z,common-page-size=16384',str(C),'-L'+str(STUBS),'-lSDL2','-ldl','-lc','-o',str(LIBMAIN)], check=True)
verify_native(LIBMAIN)

entries = [
    ('AndroidManifest.xml', zipfile.ZIP_DEFLATED),
    ('resources.arsc', zipfile.ZIP_STORED),
    ('classes.dex', zipfile.ZIP_STORED),
    ('lib/arm64-v8a/libFNA3D.so', zipfile.ZIP_STORED),
    ('lib/arm64-v8a/libSDL2.so', zipfile.ZIP_STORED),
    ('lib/arm64-v8a/libmain.so', zipfile.ZIP_STORED),
]

def aligned_extra(cur, name, align=16384):
    base_off = cur + 30 + len(name.encode())
    total = (-base_off) % align
    if total == 0:
        return b''
    if total < 4:
        total += align
    return struct.pack('<HH', 0xD935, total - 4) + b'\0' * (total - 4)

if UNSIGNED.exists():
    UNSIGNED.unlink()
with zipfile.ZipFile(UNSIGNED, 'w', allowZip64=False) as z:
    for name, method in entries:
        data = LIBMAIN.read_bytes() if name.endswith('/libmain.so') else (APKDIR / name).read_bytes()
        zi = zipfile.ZipInfo(name, date_time=(2026,10,7,2,5,0))
        zi.compress_type = method
        zi.create_system = 0
        zi.external_attr = 0
        if method == zipfile.ZIP_STORED:
            zi.extra = aligned_extra(z.fp.tell(), name, 16384 if name.startswith('lib/') else 4)
        z.writestr(zi, data, compress_type=method, compresslevel=9 if method == zipfile.ZIP_DEFLATED else None)

with zipfile.ZipFile(UNSIGNED) as z, open(UNSIGNED, 'rb') as f:
    for zi in z.infolist():
        f.seek(zi.header_offset)
        h = f.read(30)
        _,_,_,_,_,_,_,_,_,nlen,xlen = struct.unpack('<IHHHHHIIIHH', h)
        off = zi.header_offset + 30 + nlen + xlen
        if zi.filename.startswith('lib/') and zi.filename.endswith('.so') and off % 16384:
            raise SystemExit(f'unaligned {zi.filename}: {off}')

key = serialization.load_pem_private_key(KEY.read_bytes(), password=None)
cert_der = CERT.read_bytes()
cert = x509.load_der_x509_certificate(cert_der)
pub_der = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
assert cert.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo) == pub_der
raw = UNSIGNED.read_bytes()
eocd = raw.rfind(b'PK\x05\x06')
cd_offset = struct.unpack_from('<I', raw, eocd + 16)[0]
cd_size = struct.unpack_from('<I', raw, eocd + 12)[0]
assert cd_offset + cd_size == eocd
sec1 = raw[:cd_offset]
sec3 = raw[cd_offset:eocd]
sec4 = bytearray(raw[eocd:])
struct.pack_into('<I', sec4, 16, cd_offset)
chunk_size = 1024 * 1024

def content_digest(sections):
    ds = []
    for sec in sections:
        for off in range(0, len(sec), chunk_size):
            c = bytes(sec[off:off + chunk_size])
            ds.append(hashlib.sha256(b'\xA5' + struct.pack('<I', len(c)) + c).digest())
    return hashlib.sha256(b'\x5A' + struct.pack('<I', len(ds)) + b''.join(ds)).digest()

digest = content_digest([sec1, sec3, sec4])
alg = 0x0103
lp = lambda b: struct.pack('<I', len(b)) + b
signed_data = lp(lp(struct.pack('<I', alg) + lp(digest))) + lp(lp(cert_der)) + lp(b'')
sig = key.sign(signed_data, padding.PKCS1v15(), hashes.SHA256())
signer = lp(signed_data) + lp(lp(struct.pack('<I', alg) + lp(sig))) + lp(pub_der)
v2 = lp(lp(signer))
pair = struct.pack('<Q', 4 + len(v2)) + struct.pack('<I', 0x7109871A) + v2
block_size = len(pair) + 8 + 16
block = struct.pack('<Q', block_size) + pair + struct.pack('<Q', block_size) + b'APK Sig Block 42'
new_cd = cd_offset + len(block)
final = bytearray(raw[eocd:])
struct.pack_into('<I', final, 16, new_cd)
key.public_key().verify(sig, signed_data, padding.PKCS1v15(), hashes.SHA256())
SIGNED.write_bytes(sec1 + block + sec3 + final)
sha = verify(SIGNED, 16384, cert_der)
print(SIGNED)
print(sha)
