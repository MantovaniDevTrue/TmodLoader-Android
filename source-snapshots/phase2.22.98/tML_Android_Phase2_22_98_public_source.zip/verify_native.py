import struct
from pathlib import Path

def verify_native(path):
 b=Path(path).read_bytes()
 assert b[:6]==b'\x7fELF\x02\x01'
 assert struct.unpack_from('<HH',b,16)==(3,183)
 phoff=struct.unpack_from('<Q',b,32)[0]
 phsize,nph=struct.unpack_from('<HH',b,54)
 segments=[struct.unpack_from('<IIQQQQQQ',b,phoff+i*phsize) for i in range(nph)]
 writable=[]
 for typ,flags,off,addr,_,size,memsz,align in segments:
  assert off+size<=len(b)
  if typ==1:
   assert align>=16384 and align&(align-1)==0
   assert off%align==addr%align
   assert flags&3!=3,'Writable/executable segment'
   assert size<=memsz
   if flags&2:writable.append((addr,addr+memsz))
  if typ==2:
   for pos in range(off,off+size,16):
    tag,value=struct.unpack_from('<qQ',b,pos)
    assert tag!=22,'DT_TEXTREL'
    if tag==30:assert not value&4,'DF_TEXTREL'
 shoff=struct.unpack_from('<Q',b,40)[0]
 shsize,nsh,_=struct.unpack_from('<HHH',b,58)
 sections=[struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*shsize) for i in range(nsh)]
 imports=set();exports=set()
 for sec in sections:
  _,typ,_,_,off,size,link,_,_,entsz=sec
  if typ==11:
   strings=sections[link];table=b[strings[4]:strings[4]+strings[5]]
   for pos in range(off,off+size,entsz):
    name,info,other,idx,value,sz=struct.unpack_from('<IBBHQQ',b,pos)
    name=table[name:].split(b'\0',1)[0].decode()
    if name and idx==0:imports.add(name)
    elif name:exports.add(name)
  if typ==4:
   for pos in range(off,off+size,entsz):
    addr,info,addend=struct.unpack_from('<QQq',b,pos)
    assert any(lo<=addr and addr+8<=hi for lo,hi in writable),'Relocation target outside writable segment'
    assert info&0xffffffff in (1025,1026,1027),'Unexpected relocation type'
 allowed=set('fopen fgets fread fwrite fclose ferror fgetc rename remove snprintf strlen strcmp mkdir chdir memset strdup setenv mprotect getpagesize dlopen dlsym dlclose dlerror SDL_AndroidGetInternalStoragePath SDL_ShowSimpleMessageBox pthread_attr_init pthread_attr_setstacksize pthread_attr_destroy pthread_create pthread_join'.split())
 assert imports<=allowed,imports-allowed
 assert 'SDL_main' in exports
 return {'imports':sorted(imports),'arm64':True,'alignment':16384,'text_relocations':False}

if __name__=='__main__':
 import sys
 print(verify_native(sys.argv[1]))
