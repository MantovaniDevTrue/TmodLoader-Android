void dlopen(void) {}
void dlsym(void) {}
void dlclose(void) {}
void dlerror(void) {}
