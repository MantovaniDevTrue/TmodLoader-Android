void SDL_AndroidGetInternalStoragePath(void) {}
void SDL_ShowSimpleMessageBox(void) {}
