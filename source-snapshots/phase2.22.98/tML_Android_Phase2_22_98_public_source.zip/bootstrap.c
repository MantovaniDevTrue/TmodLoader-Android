typedef unsigned long size_t;
typedef unsigned int u32;
typedef void FILE;

extern FILE *fopen(const char *, const char *);
extern char *fgets(char *, int, FILE *);
extern size_t fread(void *, size_t, size_t, FILE *);
extern size_t fwrite(const void *, size_t, size_t, FILE *);
extern int fclose(FILE *);
extern int ferror(FILE *);
extern int fgetc(FILE *);
extern int rename(const char *, const char *);
extern int remove(const char *);
extern char *strdup(const char *);
extern int setenv(const char *, const char *, int);
extern int snprintf(char *, size_t, const char *, ...);
extern size_t strlen(const char *);
extern int strcmp(const char *, const char *);
extern int mkdir(const char *, unsigned int);
extern int chdir(const char *);
extern void *memset(void *, int, size_t);
extern int mprotect(void *, size_t, int);
extern int getpagesize(void);
extern void *dlopen(const char *, int);
extern void *dlsym(void *, const char *);
extern const char *dlerror(void);
extern int dlclose(void *);
extern const char *SDL_AndroidGetInternalStoragePath(void);
extern int SDL_ShowSimpleMessageBox(unsigned int, const char *, const char *, void *);
extern int pthread_attr_init(void *);
extern int pthread_attr_setstacksize(void *, size_t);
extern int pthread_attr_destroy(void *);
extern int pthread_create(unsigned long *, const void *, void *(*)(void *), void *);
extern int pthread_join(unsigned long, void **);

#define RTLD_NOW 2
#define RTLD_GLOBAL 0x100
#define MONO_AOT_MODE_NORMAL 1
#define PROT_READ 1
#define PROT_WRITE 2
#define PROT_EXEC 4

static const char *BASE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8";
static const char *RUNTIME = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/runtime";
static const char *DEPS = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/deps";
static const char *TPA = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/runtime/tpa.paths";
static const char *NATIVE_LIST = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/runtime/native.list";
static const char *FNA = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/runtime/FNA.dll";
static const char *SPLIT = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/probes/Split.dll";
static const char *SPLIT_TMOD = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/probes/Split.tmod";
static const char *MODS_DIR = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/save/tModLoader/Mods";
static const char *SPLIT_TMOD_MODPATH = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/save/tModLoader/Mods/Split.tmod";
static const char *ENABLED_JSON = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/save/tModLoader/Mods/enabled.json";
static const char *TML = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/deps/tModLoader.dll";
static const char *LOG4NET = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/deps/log4net.dll";
static const char *CONFIGMGR = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/deps/System.Configuration.ConfigurationManager.dll";
static const char *LOGFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98.txt";
static const char *STATEFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_state.txt";
static const char *DEEPFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_npc65_deep.txt";
static const char *PROGRESSFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_npcid_progress.txt";
static const char *JITFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_npcid_jit.txt";
static const char *BESTIARYFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_bestiary_helpers.txt";
static const char *STACKFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_stack.txt";
static const char *POSTCONTENTFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_postcontent.txt";
static const char *DISPLAYFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_display.txt";
static const char *BINDINGFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_fna3d_binding.txt";
static const char *LOADCONTENTFILE = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/monovm_phase2_22_98_loadcontent.txt";
static const char *SAVE_PARENT = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/save";
static const char *SAVE_PATH = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/save/tModLoader";
static const char *WORK_DIR = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/work";
static const char *LOG_DIR_ABS = "/storage/emulated/0/Android/media/com.mantovani.tmlmono8/work/tModLoader-Logs";

static char tpa_buf[65536];
static char report[24576];
static char private_dir[1024];
static char private_mono[1200];
static char assembly_paths[2200];
static char requested_assemblies[4096];
static int native_staged = 0;
static int preload_calls = 0;
static const char *(*g_assembly_name_get_name)(void *) = 0;

static void *(*g_class_get_fields)(void *, void **) = 0;
static const char *(*g_field_get_name)(void *) = 0;
static unsigned int (*g_field_get_flags)(void *) = 0;
static void *(*g_field_get_type)(void *) = 0;
static int (*g_type_get_type)(void *) = 0;
static int (*g_type_is_reference)(void *) = 0;
static void *(*g_class_vtable)(void *, void *) = 0;
static void (*g_field_get_value)(void *, void *, void *) = 0;
static void (*g_field_static_get_value)(void *, void *, void *) = 0;

static void *(*g_invoke)(void *, void *, void **, void **) = 0;
static void *(*g_object_class)(void *) = 0;
static void *(*g_parent_class)(void *) = 0;
static const char *(*g_class_name)(void *) = 0;
static const char *(*g_class_namespace)(void *) = 0;
static void *(*g_find_field)(void *, const char *) = 0;
static char *(*g_string_utf8)(void *) = 0;
static void (*g_mono_free)(void *) = 0;
static void write_text(const char *path, const char *text);
static void write_state_line(const char *event, const char *entity, int id, int depth);
static void write_npcid_progress(const char *event, void *method);
static void *(*g_method_get_class)(void *) = 0;
static const char *(*g_method_get_name)(void *) = 0;
static unsigned int (*g_method_get_token)(void *) = 0;
static void *(*g_class_get_method_from_name)(void *, const char *, int) = 0;
static int startup_trace_count = 0;
static int startup_trace_enabled = 0;
static int npc_setdefaults_depth = 0;
static int npc_setdefaults_top_seq = 0;
static int npc_setdefaults_current_id = -999999;
static int projectile_setdefaults_depth = 0;
static int projectile_setdefaults_top_seq = 0;
static int projectile_setdefaults_current_id = -1;
static int item_setdefaults_depth = 0;
static int item_setdefaults_top_seq = 0;
static int item_setdefaults_current_id = -1;
static int content_samples_depth = 0;
static int diagnostic_event_seq = 0;
static int setfactory_getname_calls = 0;
static int deep_trace_count = 0;
static int npc65_dictionary_adds = 0;
static int npc65_list_adds = 0;
static int npcid_sets_cctor_active = 0;
static int npcid_sets_cctor_completed = 0;
static void *g_npcid_sets_cctor_method = 0;
static void *g_npcid_draw_offset_creation_method = 0;
static void *g_npcid_get_redigit_entries_method = 0;
static void *g_npcid_get_leinfors_entries_method = 0;
static void *g_npcid_get_grox_entries_method = 0;
static void *g_npcid_sets_class = 0;
static int npcid_bestiary_draw_active = 0;
static int npcid_bestiary_helper_depth = 0;
static const char *npcid_bestiary_helper = "<none>";
static int npcid_bestiary_adds_at_helper_enter = 0;
static int npcid_jit_event_seq = 0;
static int postcontent_trace_armed = 0;
static int postcontent_event_seq = 0;
static int display_trace_active = 0;
static int init_targets_active = 0;
static int save_settings_active = 0;
static int display_event_seq = 0;
static int save_put_count = 0;
static int post_texture_upload_armed = 0;
static int loadcontent_event_seq = 0;
static int loadcontent_exception_seq = 0;
static void *g_domain_diag = 0;
static void *g_main_class_diag = 0;
static void *g_player_class_diag = 0;
static int postcontent_method_selected(void *method);
static void write_postcontent_event(const char *kind, void *method);
static int display_method_selected(void *method);
static void write_display_event(const char *kind, void *method);
static int loadcontent_method_selected(void *method);
static void write_loadcontent_event(const char *kind, void *method);
static void exception_summary(void *exc, char *out, size_t cap);
static void append_static_field_status(void *domain, void *klass, const char *field_name, char *out, size_t cap);
#define MANAGED_ENTER_RING_SIZE 48
static char managed_enter_ring[MANAGED_ENTER_RING_SIZE][256];
static int managed_enter_ring_next = 0;
static int managed_enter_ring_count = 0;

#define MONO_PROFILER_CALL_INSTRUMENTATION_ENTER 2
#define MONO_PROFILER_CALL_INSTRUMENTATION_LEAVE 8
#define MONO_PROFILER_CALL_INSTRUMENTATION_EXCEPTION_LEAVE 64

static int str_starts_with(const char *s, const char *prefix) {
    if (!s || !prefix) return 0;
    while (*prefix) {
        if (*s++ != *prefix++) return 0;
    }
    return 1;
}

static int str_contains(const char *s, const char *needle) {
    if (!s || !needle || !*needle) return 0;
    for (; *s; s++) {
        const char *a = s;
        const char *b = needle;
        while (*a && *b && *a == *b) { a++; b++; }
        if (!*b) return 1;
    }
    return 0;
}

static int method_is_collection_progress_target(void *method) {
    if (!method || !g_method_get_class || !g_method_get_name || !g_class_name || !g_class_namespace)
        return 0;
    void *klass = g_method_get_class(method);
    if (!klass) return 0;
    const char *ns = g_class_namespace(klass);
    const char *cn = g_class_name(klass);
    const char *mn = g_method_get_name(method);
    if (!ns || !cn || !mn) return 0;
    if (strcmp(ns, "System.Collections.Generic")) return 0;
    if (!strcmp(cn, "Dictionary`2") && !strcmp(mn, "Add")) return 1;
    if (!strcmp(cn, "List`1") && !strcmp(mn, "Add")) return 1;
    return 0;
}

static int npcid_bestiary_method_selected(void *method) {
    if (!method) return 0;
    if (method == g_npcid_draw_offset_creation_method ||
        method == g_npcid_get_redigit_entries_method ||
        method == g_npcid_get_leinfors_entries_method ||
        method == g_npcid_get_grox_entries_method)
        return 1;
    if (!g_method_get_class || !g_method_get_name) return 0;
    void *klass = g_method_get_class(method);
    const char *mn = g_method_get_name(method);
    if (klass == g_npcid_sets_class && mn &&
        (str_contains(mn, "NPCBestiaryDrawOffsetCreation") ||
         str_contains(mn, "GetRedigitEntries") ||
         str_contains(mn, "GetLeinforsEntries") ||
         str_contains(mn, "GetGroxEntries")))
        return 1;
    return 0;
}

static const char *npcid_bestiary_method_label(void *method) {
    if (method == g_npcid_draw_offset_creation_method) return "NPCBestiaryDrawOffsetCreation";
    if (method == g_npcid_get_redigit_entries_method) return "GetRedigitEntries";
    if (method == g_npcid_get_leinfors_entries_method) return "GetLeinforsEntries";
    if (method == g_npcid_get_grox_entries_method) return "GetGroxEntries";
    if (method && g_method_get_name) {
        const char *mn = g_method_get_name(method);
        if (mn && str_contains(mn, "NPCBestiaryDrawOffsetCreation")) return "FilterPaths/local";
        if (mn && str_contains(mn, "GetRedigitEntries")) return "GetRedigitEntries/generated";
        if (mn && str_contains(mn, "GetLeinforsEntries")) return "GetLeinforsEntries/generated";
        if (mn && str_contains(mn, "GetGroxEntries")) return "GetGroxEntries/generated";
    }
    return "<other>";
}

static void write_bestiary_event(const char *event, void *method) {
    char line[1024];
    const char *ns = "";
    const char *cn = "";
    const char *mn = "";
    unsigned int token = 0;
    if (method && g_method_get_class && g_method_get_name) {
        void *klass = g_method_get_class(method);
        if (klass) {
            ns = g_class_namespace ? g_class_namespace(klass) : "";
            cn = g_class_name ? g_class_name(klass) : "";
        }
        mn = g_method_get_name(method);
        if (g_method_get_token) token = g_method_get_token(method);
    }
    snprintf(line, sizeof(line),
             "event=%s drawActive=%d helperDepth=%d helper=%s dictAdds=%d helperStartAdds=%d deltaAdds=%d token=0x%08x method=%s.%s::%s\n",
             event ? event : "<null>", npcid_bestiary_draw_active,
             npcid_bestiary_helper_depth, npcid_bestiary_helper ? npcid_bestiary_helper : "<null>",
             npc65_dictionary_adds, npcid_bestiary_adds_at_helper_enter,
             npc65_dictionary_adds - npcid_bestiary_adds_at_helper_enter,
             token, ns ? ns : "", cn ? cn : "", mn ? mn : "");
    write_text(BESTIARYFILE, line);
}

static int deep_trace_method_selected(void *method) {
    if (!method || !g_method_get_class || !g_method_get_name || !g_class_name || !g_class_namespace)
        return 0;
    if (method == g_npcid_sets_cctor_method || npcid_bestiary_method_selected(method)) return 1;
    if (method_is_collection_progress_target(method)) return 1;
    void *klass = g_method_get_class(method);
    if (!klass) return 0;
    const char *ns = g_class_namespace(klass);
    const char *cn = g_class_name(klass);
    const char *mn = g_method_get_name(method);
    if (!ns) ns = "";
    if (!cn) cn = "";
    if (!mn) mn = "";
    if (!strcmp(ns, "Terraria.ID")) return 1;
    if (!strcmp(ns, "Terraria") && !strcmp(cn, "NPC")) return 1;
    if (!strcmp(ns, "Terraria.ModLoader") && (!strcmp(cn, "NPCLoader") || !strcmp(cn, "BuffLoader"))) return 1;
    if (!strcmp(ns, "ReLogic.Reflection") && !strcmp(cn, "IdDictionary")) return 1;
    if (!strcmp(ns, "System.Linq") && !strcmp(cn, "Enumerable") && !strcmp(mn, "Any")) return 1;
    return 0;
}

static int npc65_deep_active(void) {
    return npc_setdefaults_top_seq == 1 && npc_setdefaults_current_id == -65 && npc_setdefaults_depth > 0;
}

static void deep_trace_line(const char *kind, void *method) {
    if (!npc65_deep_active() || !method || !deep_trace_method_selected(method) || deep_trace_count >= 6000)
        return;
    void *klass = g_method_get_class(method);
    const char *ns = klass ? g_class_namespace(klass) : "";
    const char *cn = klass ? g_class_name(klass) : "";
    const char *mn = g_method_get_name(method);
    unsigned int token = g_method_get_token ? g_method_get_token(method) : 0;
    char line[768];
    snprintf(line, sizeof(line), "DEEP_%s seq=%d depth=%d token=0x%08x %s.%s::%s\n",
             kind, ++diagnostic_event_seq, npc_setdefaults_depth, token,
             ns ? ns : "", cn ? cn : "", mn ? mn : "");
    write_text(DEEPFILE, line);
    deep_trace_count++;
}

static int startup_trace_method_selected(void *method) {
    if (!method || !g_method_get_class || !g_method_get_name || !g_class_name || !g_class_namespace)
        return 0;
    void *klass = g_method_get_class(method);
    if (!klass) return 0;
    const char *ns = g_class_namespace(klass);
    const char *cn = g_class_name(klass);
    const char *mn = g_method_get_name(method);
    if (!ns) ns = "";
    if (!cn) cn = "";
    if (!mn) mn = "";

    if (!strcmp(ns, "Terraria.ID") && !strcmp(cn, "ContentSamples") && !strcmp(mn, "Initialize"))
        return 1;
    if (!strcmp(ns, "Terraria") && !strcmp(cn, "NPC") && !strcmp(mn, "SetDefaults"))
        return 1;
    if (!strcmp(ns, "Terraria") && !strcmp(cn, "Projectile") && !strcmp(mn, "SetDefaults"))
        return 1;
    if (!strcmp(ns, "Terraria") && !strcmp(cn, "Item") && !strcmp(mn, "SetDefaults"))
        return 1;
    if (!strcmp(ns, "Terraria.ID") && !strcmp(cn, "SetFactory") && !strcmp(mn, "<.ctor>b__31_0"))
        return 1;
    if (!strcmp(ns, "Terraria") && !strcmp(cn, "Main") && !strcmp(mn, "Initialize"))
        return 1;

    return 0;
}
static void remember_managed_enter(void *method) {
    if (!startup_trace_enabled || (!startup_trace_method_selected(method) && !postcontent_method_selected(method) && !display_method_selected(method) && !loadcontent_method_selected(method)) || !g_method_get_class || !g_method_get_name)
        return;
    void *klass = g_method_get_class(method);
    const char *ns = klass && g_class_namespace ? g_class_namespace(klass) : "";
    const char *cn = klass && g_class_name ? g_class_name(klass) : "";
    const char *mn = g_method_get_name(method);
    snprintf(managed_enter_ring[managed_enter_ring_next],
             sizeof(managed_enter_ring[managed_enter_ring_next]),
             "%s.%s::%s", ns ? ns : "", cn ? cn : "", mn ? mn : "");
    managed_enter_ring_next = (managed_enter_ring_next + 1) % MANAGED_ENTER_RING_SIZE;
    if (managed_enter_ring_count < MANAGED_ENTER_RING_SIZE)
        managed_enter_ring_count++;
}

static void format_recent_managed_enters(char *out, size_t cap, int max_entries) {
    if (!out || cap == 0) return;
    out[0] = 0;
    int count = managed_enter_ring_count;
    if (max_entries > 0 && count > max_entries)
        count = max_entries;
    int start = managed_enter_ring_next - count;
    while (start < 0) start += MANAGED_ENTER_RING_SIZE;
    for (int i = 0; i < count; i++) {
        int pos = (start + i) % MANAGED_ENTER_RING_SIZE;
        size_t used = strlen(out);
        if (used + strlen(managed_enter_ring[pos]) + 8 >= cap)
            break;
        snprintf(out + used, cap - used, "%02d %s\n", i + 1, managed_enter_ring[pos]);
    }
    if (!out[0])
        snprintf(out, cap, "<none>\n");
}

static void startup_trace_line(const char *kind, void *method) {
    if (!startup_trace_enabled || startup_trace_count >= 12000 || !startup_trace_method_selected(method))
        return;
    void *klass = g_method_get_class(method);
    const char *ns = klass ? g_class_namespace(klass) : "";
    const char *cn = klass ? g_class_name(klass) : "";
    const char *mn = g_method_get_name(method);
    char line[640];
    snprintf(line, sizeof(line), "MANAGED_TRACE_%s=%s.%s::%s\n", kind,
             ns ? ns : "", cn ? cn : "", mn ? mn : "");
    write_text(LOGFILE, line);
    startup_trace_count++;
}

static int npcid_jit_should_log(void *method) {
    if (!method || !g_method_get_class || !g_method_get_name || !g_class_name || !g_class_namespace)
        return 0;
    if (npcid_bestiary_method_selected(method)) return 1;
    if (!npcid_sets_cctor_active && !(npc65_deep_active() && npc65_dictionary_adds >= 40))
        return 0;
    void *klass = g_method_get_class(method);
    if (!klass) return 0;
    const char *ns = g_class_namespace(klass);
    const char *cn = g_class_name(klass);
    if (!ns) ns = "";
    if (!cn) cn = "";
    if (!strcmp(ns, "Terraria.ID")) return 1;
    if (!strcmp(ns, "Terraria") && !strcmp(cn, "NPC")) return 1;
    if (!strcmp(ns, "Terraria.ModLoader") && (!strcmp(cn, "NPCLoader") || !strcmp(cn, "BuffLoader"))) return 1;
    if (!strcmp(ns, "ReLogic.Reflection") && !strcmp(cn, "IdDictionary")) return 1;
    if (!strcmp(ns, "System.Collections.Generic")) return 1;
    if (!strcmp(ns, "System.Linq")) return 1;
    return 0;
}

static void npcid_jit_event(const char *kind, void *method) {
    if (!npcid_jit_should_log(method)) return;
    void *klass = g_method_get_class(method);
    const char *ns = klass ? g_class_namespace(klass) : "";
    const char *cn = klass ? g_class_name(klass) : "";
    const char *mn = g_method_get_name(method);
    unsigned int token = g_method_get_token ? g_method_get_token(method) : 0;
    char line[896];
    snprintf(line, sizeof(line),
             "JIT_%s seq=%d cctorActive=%d cctorCompleted=%d dictAdds=%d npcDepth=%d token=0x%08x %s.%s::%s\n",
             kind ? kind : "EVENT", ++npcid_jit_event_seq,
             npcid_sets_cctor_active, npcid_sets_cctor_completed,
             npc65_dictionary_adds, npc_setdefaults_depth, token,
             ns ? ns : "", cn ? cn : "", mn ? mn : "");
    write_text(JITFILE, line);
}

static void startup_profiler_jit_begin(void *prof, void *method) {
    (void)prof;
    npcid_jit_event("BEGIN", method);
    if (postcontent_trace_armed && postcontent_method_selected(method))
        write_postcontent_event("JIT_BEGIN", method);
    if (post_texture_upload_armed && loadcontent_method_selected(method))
        write_loadcontent_event("JIT_BEGIN", method);
}

static void startup_profiler_jit_failed(void *prof, void *method) {
    (void)prof;
    npcid_jit_event("FAILED", method);
    if (postcontent_trace_armed && postcontent_method_selected(method))
        write_postcontent_event("JIT_FAILED", method);
    if (post_texture_upload_armed && loadcontent_method_selected(method))
        write_loadcontent_event("JIT_FAILED", method);
}

static void startup_profiler_jit_done(void *prof, void *method, void *jinfo) {
    (void)prof; (void)jinfo;
    npcid_jit_event("DONE", method);
    if (postcontent_trace_armed && postcontent_method_selected(method))
        write_postcontent_event("JIT_DONE", method);
    if (post_texture_upload_armed && loadcontent_method_selected(method))
        write_loadcontent_event("JIT_DONE", method);
}

static int display_method_selected(void *method) {
    if (!method || !g_method_get_class || !g_method_get_name || !g_class_name || !g_class_namespace)
        return 0;
    void *klass = g_method_get_class(method);
    if (!klass) return 0;
    const char *ns = g_class_namespace(klass);
    const char *cn = g_class_name(klass);
    const char *mn = g_method_get_name(method);
    if (!ns) ns = "";
    if (!cn) cn = "";
    if (!mn) mn = "";
    if (!strcmp(ns, "Terraria") && !strcmp(cn, "Main") &&
        (!strcmp(mn, "Initialize") || !strcmp(mn, "ClientInitialize") || !strcmp(mn, "LoadSettings") ||
         !strcmp(mn, "SetDisplayMode") || !strcmp(mn, "InitTargets") || !strcmp(mn, "SaveSettings"))) return 1;
    if (!strcmp(cn, "Preferences") &&
        (!strcmp(mn, "Clear") || !strcmp(mn, "Put") || !strcmp(mn, "Save"))) return 1;
    if (!strcmp(ns, "Terraria.GameInput") && !strcmp(cn, "PlayerInput") && !strcmp(mn, "Save")) return 1;
    if (!strcmp(ns, "Terraria.ModLoader") && !strcmp(cn, "ModLoader") && !strcmp(mn, "SaveConfiguration")) return 1;
    if (!strcmp(ns, "Terraria.GameContent") && !strcmp(cn, "SecretSeedsTracker") && !strcmp(mn, "GetStringsToSave")) return 1;
    if (!strcmp(ns, "Microsoft.Xna.Framework.Graphics") &&
        (!strcmp(cn, "RenderTarget2D") || !strcmp(cn, "RenderTargetBinding") || !strcmp(cn, "GraphicsDevice")) &&
        (!strcmp(mn, ".ctor") || str_contains(mn, "RenderTarget") || str_contains(mn, "SetRenderTarget"))) return 1;
    if (!strcmp(ns, "Microsoft.Xna.Framework") && !strcmp(cn, "GraphicsDeviceManager") && !strcmp(mn, "ApplyChanges")) return 1;
    return 0;
}

static void write_display_event(const char *kind, void *method) {
    if (!method || !g_method_get_class || !g_method_get_name) return;
    void *klass = g_method_get_class(method);
    const char *ns = klass && g_class_namespace ? g_class_namespace(klass) : "";
    const char *cn = klass && g_class_name ? g_class_name(klass) : "";
    const char *mn = g_method_get_name(method);
    unsigned int token = g_method_get_token ? g_method_get_token(method) : 0;
    char line[1024];
    snprintf(line, sizeof(line),
             "DISPLAY_%s seq=%d active=%d initTargets=%d saveSettings=%d putCount=%d token=0x%08x method=%s.%s::%s\n",
             kind ? kind : "EVENT", ++display_event_seq, display_trace_active,
             init_targets_active, save_settings_active, save_put_count, token,
             ns ? ns : "", cn ? cn : "", mn ? mn : "");
    write_text(DISPLAYFILE, line);
}

static void append_instance_field_status(void *klass, void *object, const char *field_name, char *out, size_t cap) {
    if (!out || cap == 0 || !field_name) return;
    size_t used = strlen(out);
    if (used + 112 >= cap) return;
    if (!klass || !object || !g_find_field || !g_field_get_value) {
        snprintf(out + used, cap - used, "%s=<instance/api unavailable>\n", field_name);
        return;
    }
    void *field = g_find_field(klass, field_name);
    if (!field) {
        snprintf(out + used, cap - used, "%s=<field missing>\n", field_name);
        return;
    }
    void *value = 0;
    g_field_get_value(object, field, &value);
    snprintf(out + used, cap - used, "%s=%s ptr=0x%lx\n", field_name, value ? "SET" : "NULL", (unsigned long)value);
}

static void write_savesettings_audit(void) {
    char out[4096];
    snprintf(out, sizeof(out), "SAVESETTINGS_AUDIT_BEGIN\n");
    append_static_field_status(g_domain_diag, g_main_class_diag, "Configuration", out, sizeof(out));
    append_static_field_status(g_domain_diag, g_main_class_diag, "InputProfiles", out, sizeof(out));
    append_static_field_status(g_domain_diag, g_main_class_diag, "instance", out, sizeof(out));
    append_static_field_status(g_domain_diag, g_main_class_diag, "graphics", out, sizeof(out));
    append_static_field_status(g_domain_diag, g_main_class_diag, "ResourceSetsManager", out, sizeof(out));
    append_static_field_status(g_domain_diag, g_player_class_diag, "Settings", out, sizeof(out));
    void *instance = 0;
    if (g_main_class_diag && g_domain_diag && g_find_field && g_class_vtable && g_field_static_get_value) {
        void *f = g_find_field(g_main_class_diag, "instance");
        void *vt = g_class_vtable(g_domain_diag, g_main_class_diag);
        if (f && vt) g_field_static_get_value(vt, f, &instance);
    }
    append_instance_field_status(g_main_class_diag, instance, "waterfallManager", out, sizeof(out));
    append_instance_field_status(g_main_class_diag, instance, "_waterfallManager", out, sizeof(out));
    append_instance_field_status(g_main_class_diag, instance, "gameTips", out, sizeof(out));
    append_instance_field_status(g_main_class_diag, instance, "gameTipsProvider", out, sizeof(out));
    size_t used = strlen(out);
    if (used + 64 < sizeof(out)) snprintf(out + used, sizeof(out) - used, "SAVESETTINGS_AUDIT_END\n");
    write_text(DISPLAYFILE, out);
}

static void startup_profiler_exception_throw(void *prof, void *exc) {
    (void)prof;
    if (!display_trace_active && !init_targets_active && !save_settings_active && !post_texture_upload_armed) return;
    char detail[2048];
    exception_summary(exc, detail, sizeof(detail));
    char line[2600];
    snprintf(line, sizeof(line),
             "FIRST_CHANCE_EXCEPTION seq=%d active=%d initTargets=%d saveSettings=%d putCount=%d detail=%s\n",
             ++display_event_seq, display_trace_active, init_targets_active, save_settings_active,
             save_put_count, detail[0] ? detail : "<empty>");
    write_text(DISPLAYFILE, line);
    if (post_texture_upload_armed) {
        char loadline[2600];
        snprintf(loadline, sizeof(loadline), "LOADCONTENT_FIRST_CHANCE_EXCEPTION seq=%d detail=%s\n",
                 ++loadcontent_exception_seq, detail[0] ? detail : "<empty>");
        write_text(LOADCONTENTFILE, loadline);
        write_state_line("FIRST_CHANCE_EXCEPTION", "LOADCONTENT", -1, loadcontent_exception_seq);
    }
}

static int postcontent_method_selected(void *method) {
    if (!method || !g_method_get_class || !g_method_get_name || !g_class_name || !g_class_namespace)
        return 0;
    void *klass = g_method_get_class(method);
    if (!klass) return 0;
    const char *ns = g_class_namespace(klass);
    const char *cn = g_class_name(klass);
    const char *mn = g_method_get_name(method);
    if (!ns) ns = "";
    if (!cn) cn = "";
    if (!mn) mn = "";

    if (!strcmp(ns, "Terraria.ModLoader")) {
        if (!strcmp(cn, "ModContent") && (!strcmp(mn, "Load") || !strcmp(mn, "LoadModContent") || !strcmp(mn, "SetupBestiary") || !strcmp(mn, "SetupRecipes"))) return 1;
        if ((!strcmp(cn, "TileLoader") || !strcmp(cn, "BuffLoader") || !strcmp(cn, "BiomeConversionLoader") ||
             !strcmp(cn, "ItemLoader") || !strcmp(cn, "NPCLoader") || !strcmp(cn, "PrefixLoader") ||
             !strcmp(cn, "ProjectileLoader") || !strcmp(cn, "PylonLoader") || !strcmp(cn, "WallLoader") ||
             !strcmp(cn, "EmoteBubbleLoader") || !strcmp(cn, "MapLoader") || !strcmp(cn, "PlantLoader") ||
             !strcmp(cn, "RarityLoader") || !strcmp(cn, "LocalizationLoader") || !strcmp(cn, "MenuLoader") ||
             !strcmp(cn, "BossBarLoader")) &&
            (!strcmp(mn, "PostSetupContent") || !strcmp(mn, "FinishSetup") || !strcmp(mn, "GotoSavedModMenu") || !strcmp(mn, "GotoSavedStyle"))) return 1;
        if (!strcmp(cn, "SystemLoader") && (!strcmp(mn, "PostSetupContent") || !strcmp(mn, "ModifyGameTipVisibility"))) return 1;
        if (!strcmp(cn, "NPCShopDatabase") && (!strcmp(mn, "Initialize") || !strcmp(mn, "FinishSetup"))) return 1;
        if (!strcmp(cn, "ModOrganizer") && !strcmp(mn, "SaveLastLaunchedMods")) return 1;
        if (!strcmp(cn, "MemoryTracking") && !strcmp(mn, "Finish")) return 1;
    }
    if (!strcmp(ns, "Terraria.ModLoader.Config") && !strcmp(cn, "ConfigManager") && !strcmp(mn, "FinishSetup")) return 1;
    if (!strcmp(ns, "Terraria.Achievements") && !strcmp(cn, "AchievementManager") && !strcmp(mn, "FinishSetup")) return 1;
    if (!strcmp(ns, "Terraria.GameContent") && !strcmp(cn, "ArmorSetBonuses") && (!strcmp(mn, "Initialize") || !strcmp(mn, "BuildLookup"))) return 1;
    if (!strcmp(ns, "Terraria.GameContent.Bestiary") && !strcmp(cn, "NPCInteractionDatabase") && !strcmp(mn, "Populate")) return 1;
    if (!strcmp(ns, "Terraria.ID") && !strcmp(cn, "ContentSamples") && str_contains(mn, "RebuildItemCreativeSortingIDs")) return 1;
    if (!strcmp(ns, "Terraria.UI") && !strcmp(cn, "ItemSorting") && !strcmp(mn, "SetupWhiteLists")) return 1;
    return 0;
}

static void write_postcontent_event(const char *kind, void *method) {
    if (!method || !g_method_get_class || !g_method_get_name) return;
    void *klass = g_method_get_class(method);
    const char *ns = klass && g_class_namespace ? g_class_namespace(klass) : "";
    const char *cn = klass && g_class_name ? g_class_name(klass) : "";
    const char *mn = g_method_get_name(method);
    unsigned int token = g_method_get_token ? g_method_get_token(method) : 0;
    char line[1024];
    snprintf(line, sizeof(line),
             "POSTCONTENT_%s seq=%d token=0x%08x method=%s.%s::%s npcSeq=%d projectileSeq=%d itemSeq=%d\n",
             kind ? kind : "EVENT", ++postcontent_event_seq, token,
             ns ? ns : "", cn ? cn : "", mn ? mn : "",
             npc_setdefaults_top_seq, projectile_setdefaults_top_seq, item_setdefaults_top_seq);
    write_text(POSTCONTENTFILE, line);
}


static int loadcontent_method_selected(void *method) {
    if (!method || !g_method_get_class || !g_method_get_name || !g_class_name || !g_class_namespace)
        return 0;
    void *klass = g_method_get_class(method);
    if (!klass) return 0;
    const char *ns = g_class_namespace(klass);
    const char *cn = g_class_name(klass);
    const char *mn = g_method_get_name(method);
    if (!ns) ns = "";
    if (!cn) cn = "";
    if (!mn) mn = "";

    if (!strcmp(ns, "Terraria") && !strcmp(cn, "Main") &&
        (!strcmp(mn, "LoadContent") || !strcmp(mn, "LoadContent_Deferred") ||
         !strcmp(mn, "LoadContent_Shaders") || !strcmp(mn, "OnceFailedLoadingAnAsset"))) return 1;
    if (!strcmp(ns, "Terraria.Initializers") && !strcmp(cn, "AssetInitializer") && !strcmp(mn, "CreateAssetServices")) return 1;
    if (!strcmp(ns, "Microsoft.Xna.Framework") && !strcmp(cn, "GameServiceContainer") &&
        (!strcmp(mn, "GetService") || !strcmp(mn, "INTERNAL_GetService") ||
         !strcmp(mn, "AddService") || !strcmp(mn, "INTERNAL_AddService"))) return 1;
    if ((!strcmp(cn, "AssetReaderCollection") && (!strcmp(mn, ".ctor") || !strcmp(mn, "RegisterReader"))) ||
        (!strcmp(cn, "AssetRepository") && (!strcmp(mn, ".ctor") || !strcmp(mn, "SetMainThread")))) return 1;
    if ((!strcmp(ns, "ReLogic.Content.Readers") && (!strcmp(cn, "PngReader") || !strcmp(cn, "XnbReader"))) ||
        (!strcmp(ns, "Terraria.ModLoader.Assets") &&
         (!strcmp(cn, "RawImgReader") || !strcmp(cn, "FxcReader") || !strcmp(cn, "WavReader") ||
          !strcmp(cn, "MP3Reader") || !strcmp(cn, "OggReader")))) {
        if (!strcmp(mn, ".ctor")) return 1;
    }
    if (!strcmp(ns, "Terraria.Audio") &&
        ((!strcmp(cn, "SoundEngine") && !strcmp(mn, "Initialize")) ||
         (!strcmp(cn, "LegacyAudioSystem") && (!strcmp(mn, ".ctor") || !strcmp(mn, "SetPlayCallback"))))) return 1;
    if (!strcmp(ns, "Terraria.GameContent") && !strcmp(cn, "AssetSourceController") && !strcmp(mn, ".ctor")) return 1;
    if (!strcmp(cn, "VanillaContentValidator") && !strcmp(mn, ".ctor")) return 1;
    if (!strcmp(ns, "Terraria.ModLoader") && !strcmp(cn, "ModLoader") && !strcmp(mn, "PrepareAssets")) return 1;
    if (!strcmp(ns, "Terraria.ModLoader.Engine") && !strcmp(cn, "TMLContentManager") &&
        (!strcmp(mn, "get_RootDirectories") || !strcmp(mn, "OpenStream") || !strcmp(mn, "Load"))) return 1;
    if (!strcmp(ns, "ReLogic.Content.Sources") && str_contains(cn, "ContentSource") && !strcmp(mn, ".ctor")) return 1;
    return 0;
}

static void write_loadcontent_event(const char *kind, void *method) {
    if (!post_texture_upload_armed || !method || !g_method_get_class || !g_method_get_name) return;
    void *klass = g_method_get_class(method);
    const char *ns = klass && g_class_namespace ? g_class_namespace(klass) : "";
    const char *cn = klass && g_class_name ? g_class_name(klass) : "";
    const char *mn = g_method_get_name(method);
    unsigned int token = g_method_get_token ? g_method_get_token(method) : 0;
    char line[1024];
    snprintf(line, sizeof(line),
             "LOADCONTENT_%s seq=%d token=0x%08x method=%s.%s::%s\n",
             kind ? kind : "EVENT", ++loadcontent_event_seq, token,
             ns ? ns : "", cn ? cn : "", mn ? mn : "");
    write_text(LOADCONTENTFILE, line);
    write_state_line(kind ? kind : "EVENT", "LOADCONTENT", (int)token, loadcontent_event_seq);
}

static unsigned int startup_profiler_filter(void *prof, void *method) {
    (void)prof;
    if (!startup_trace_method_selected(method) && !deep_trace_method_selected(method) && !npcid_bestiary_method_selected(method) && !postcontent_method_selected(method) && !display_method_selected(method) && !loadcontent_method_selected(method)) return 0;
    return MONO_PROFILER_CALL_INSTRUMENTATION_ENTER |
           MONO_PROFILER_CALL_INSTRUMENTATION_LEAVE |
           MONO_PROFILER_CALL_INSTRUMENTATION_EXCEPTION_LEAVE;
}

static int method_is(void *method, const char *ns_want, const char *cn_want, const char *mn_want) {
    if (!method || !g_method_get_class || !g_method_get_name || !g_class_name || !g_class_namespace)
        return 0;
    void *klass = g_method_get_class(method);
    if (!klass) return 0;
    const char *ns = g_class_namespace(klass);
    const char *cn = g_class_name(klass);
    const char *mn = g_method_get_name(method);
    return ns && cn && mn && !strcmp(ns, ns_want) && !strcmp(cn, cn_want) && !strcmp(mn, mn_want);
}

static void write_defaults_sequence(const char *entity, const char *phase, int seq, int inferred_id, int depth) {
    char line[256];
    snprintf(line, sizeof(line), "%s_SETDEFAULTS_%s seq=%d inferredContentId=%d depth=%d\n",
             entity, phase, seq, inferred_id, depth);
    write_text(LOGFILE, line);
}

static int should_log_entity_seq(int seq) {
    return seq <= 8 || (seq % 32) == 0;
}

static int vanilla_npc_type_from_net_id(int id) {
    static const int net_id_map[65] = {
        81,81,1,1,1,1,1,1,1,1,6,6,31,31,77,42,42,176,176,176,
        176,173,173,183,183,3,3,132,132,186,186,187,187,188,188,189,189,190,191,192,
        193,194,2,200,200,21,21,201,201,202,202,203,203,223,223,231,231,232,232,233,
        233,234,234,235,235
    };
    if (id < 0) {
        int index = -id - 1;
        if (index >= 0 && index < 65) return net_id_map[index];
    }
    return id;
}

static void startup_profiler_enter(void *prof, void *method, void *ctx) {
    (void)prof; (void)ctx;
    remember_managed_enter(method);

    if (post_texture_upload_armed && loadcontent_method_selected(method))
        write_loadcontent_event("ENTER", method);

    if (display_method_selected(method)) {
        if (method_is(method, "Terraria", "Main", "LoadSettings") ||
            method_is(method, "Terraria", "Main", "SetDisplayMode") ||
            method_is(method, "Terraria", "Main", "InitTargets") ||
            method_is(method, "Terraria", "Main", "SaveSettings"))
            display_trace_active++;
        if (method_is(method, "Terraria", "Main", "InitTargets")) init_targets_active++;
        if (method_is(method, "Terraria", "Main", "SaveSettings")) {
            save_settings_active++;
            save_put_count = 0;
            write_savesettings_audit();
        }
        if (save_settings_active && g_method_get_class && g_class_name) {
            void *k = g_method_get_class(method);
            const char *cn = k ? g_class_name(k) : "";
            const char *mn = g_method_get_name ? g_method_get_name(method) : "";
            if (cn && mn && !strcmp(cn, "Preferences") && !strcmp(mn, "Put")) save_put_count++;
        }
        write_display_event("ENTER", method);
    }

    if (postcontent_trace_armed && postcontent_method_selected(method))
        write_postcontent_event("ENTER", method);

    if (npc65_deep_active() && method_is_collection_progress_target(method)) {
        void *klass = g_method_get_class(method);
        const char *cn = klass && g_class_name ? g_class_name(klass) : "";
        if (cn && !strcmp(cn, "Dictionary`2")) {
            npc65_dictionary_adds++;
            if (npc65_dictionary_adds <= 8 || (npc65_dictionary_adds % 16) == 0)
                write_npcid_progress("DICTIONARY_ADD", method);
            if (npcid_bestiary_draw_active && (npc65_dictionary_adds % 8) == 0)
                write_bestiary_event("DICT_ADD_PROGRESS", method);
        } else if (cn && !strcmp(cn, "List`1")) {
            npc65_list_adds++;
            if (npc65_list_adds <= 8 || (npc65_list_adds % 16) == 0)
                write_npcid_progress("LIST_ADD", method);
        }
        return;
    }

    if (method == g_npcid_draw_offset_creation_method) {
        npcid_bestiary_draw_active = 1;
        npcid_bestiary_helper = "NPCBestiaryDrawOffsetCreation";
        npcid_bestiary_helper_depth = 0;
        npcid_bestiary_adds_at_helper_enter = npc65_dictionary_adds;
        write_bestiary_event("DRAW_ENTER", method);
    } else if (method == g_npcid_get_redigit_entries_method ||
               method == g_npcid_get_leinfors_entries_method ||
               method == g_npcid_get_grox_entries_method ||
               (npcid_bestiary_draw_active && npcid_bestiary_method_selected(method) && method != g_npcid_draw_offset_creation_method)) {
        npcid_bestiary_helper_depth++;
        npcid_bestiary_helper = npcid_bestiary_method_label(method);
        npcid_bestiary_adds_at_helper_enter = npc65_dictionary_adds;
        write_bestiary_event("HELPER_ENTER", method);
    }

    if (method == g_npcid_sets_cctor_method) {
        npcid_sets_cctor_active = 1;
        write_text(LOGFILE, "NPCID_SETS_CCTOR_ENTER\n");
        write_npcid_progress("NPCID_SETS_CCTOR_ENTER", method);
        deep_trace_line("ENTER", method);
        return;
    }

    if (method_is(method, "Terraria.ID", "ContentSamples", "Initialize")) {
        content_samples_depth++;
        write_text(LOGFILE, "CONTENT_SAMPLES_ENTER\n");
        write_state_line("ENTER", "ContentSamples.Initialize", -1, content_samples_depth);
        return;
    }

    if (method_is(method, "Terraria", "NPC", "SetDefaults")) {
        if (npc_setdefaults_depth == 0) {
            npc_setdefaults_top_seq++;
            npc_setdefaults_current_id = npc_setdefaults_top_seq - 66;
            if (should_log_entity_seq(npc_setdefaults_top_seq))
                write_defaults_sequence("NPC", "TOP_ENTER", npc_setdefaults_top_seq, npc_setdefaults_current_id, 0);
            write_state_line("TOP_ENTER", "NPC", npc_setdefaults_current_id, 0);
        }
        npc_setdefaults_depth++;
        deep_trace_line("ENTER", method);
        return;
    }

    if (method_is(method, "Terraria", "Projectile", "SetDefaults")) {
        if (projectile_setdefaults_depth == 0) {
            projectile_setdefaults_top_seq++;
            projectile_setdefaults_current_id = projectile_setdefaults_top_seq - 1;
            if (should_log_entity_seq(projectile_setdefaults_top_seq))
                write_defaults_sequence("PROJECTILE", "TOP_ENTER", projectile_setdefaults_top_seq, projectile_setdefaults_current_id, 0);
            write_state_line("TOP_ENTER", "PROJECTILE", projectile_setdefaults_current_id, 0);
        }
        projectile_setdefaults_depth++;
        return;
    }

    if (method_is(method, "Terraria", "Item", "SetDefaults")) {
        if (item_setdefaults_depth == 0) {
            item_setdefaults_top_seq++;
            item_setdefaults_current_id = item_setdefaults_top_seq - 1;
            if (should_log_entity_seq(item_setdefaults_top_seq))
                write_defaults_sequence("ITEM", "TOP_ENTER", item_setdefaults_top_seq, item_setdefaults_current_id, 0);
            write_state_line("TOP_ENTER", "ITEM", item_setdefaults_current_id, 0);
        }
        item_setdefaults_depth++;
        return;
    }

    if (npcid_sets_cctor_active && method_is(method, "Terraria.ID", "SetFactory", "CreateBoolSet"))
        write_npcid_progress("SETFACTORY_CREATE_BOOL_ENTER", method);
    else if (npcid_sets_cctor_active && method_is(method, "Terraria.ID", "SetFactory", "CreateIntSet"))
        write_npcid_progress("SETFACTORY_CREATE_INT_ENTER", method);
    else if (npcid_sets_cctor_active && method_is(method, "Terraria.ID", "SetFactory", "CreateCustomSet"))
        write_npcid_progress("SETFACTORY_CREATE_CUSTOM_ENTER", method);
    else if (npcid_sets_cctor_active && method_is(method, "Terraria.ID", "SetFactory", "CreateBoolListSet"))
        write_npcid_progress("SETFACTORY_CREATE_BOOLLIST_ENTER", method);

    if (method_is(method, "Terraria.ID", "SetFactory", "<.ctor>b__31_0")) {
        setfactory_getname_calls++;
        if (setfactory_getname_calls <= 16 || (setfactory_getname_calls % 128) == 0)
            write_text(LOGFILE, "SETFACTORY_CTOR_LAMBDA_ENTER\n");
        write_state_line("ENTER", "SetFactory.ctor-lambda", npc_setdefaults_depth ? npc_setdefaults_current_id : (projectile_setdefaults_depth ? projectile_setdefaults_current_id : item_setdefaults_current_id), 0);
        deep_trace_line("ENTER", method);
        return;
    }

    deep_trace_line("ENTER", method);
    startup_trace_line("ENTER", method);
}

static void startup_profiler_leave(void *prof, void *method, void *ctx) {
    (void)prof; (void)ctx;

    if (post_texture_upload_armed && loadcontent_method_selected(method))
        write_loadcontent_event("LEAVE", method);

    if (npc65_deep_active() && method_is_collection_progress_target(method))
        return;

    if (display_method_selected(method)) {
        write_display_event("LEAVE", method);
        if (method_is(method, "Terraria", "Main", "SaveSettings") && save_settings_active > 0) save_settings_active--;
        if (method_is(method, "Terraria", "Main", "InitTargets") && init_targets_active > 0) init_targets_active--;
        if ((method_is(method, "Terraria", "Main", "LoadSettings") ||
             method_is(method, "Terraria", "Main", "SetDisplayMode") ||
             method_is(method, "Terraria", "Main", "InitTargets") ||
             method_is(method, "Terraria", "Main", "SaveSettings")) && display_trace_active > 0)
            display_trace_active--;
    }

    if (postcontent_trace_armed && postcontent_method_selected(method))
        write_postcontent_event("LEAVE", method);

    if (method == g_npcid_draw_offset_creation_method) {
        deep_trace_line("LEAVE", method);
        write_bestiary_event("DRAW_LEAVE", method);
        npcid_bestiary_draw_active = 0;
        npcid_bestiary_helper_depth = 0;
        npcid_bestiary_helper = "<none>";
        return;
    }
    if (method == g_npcid_get_redigit_entries_method ||
        method == g_npcid_get_leinfors_entries_method ||
        method == g_npcid_get_grox_entries_method ||
        (npcid_bestiary_draw_active && npcid_bestiary_method_selected(method))) {
        deep_trace_line("LEAVE", method);
        write_bestiary_event("HELPER_LEAVE", method);
        if (npcid_bestiary_helper_depth > 0) npcid_bestiary_helper_depth--;
        npcid_bestiary_helper = "NPCBestiaryDrawOffsetCreation";
        npcid_bestiary_adds_at_helper_enter = npc65_dictionary_adds;
        return;
    }

    if (method == g_npcid_sets_cctor_method) {
        deep_trace_line("LEAVE", method);
        npcid_sets_cctor_active = 0;
        npcid_sets_cctor_completed = 1;
        write_text(LOGFILE, "NPCID_SETS_CCTOR_LEAVE\n");
        write_npcid_progress("NPCID_SETS_CCTOR_LEAVE", method);
        return;
    }

    if (method_is(method, "Terraria.ID", "ContentSamples", "Initialize")) {
        if (content_samples_depth > 0) content_samples_depth--;
        write_text(LOGFILE, "CONTENT_SAMPLES_LEAVE\n");
        write_state_line("LEAVE", "ContentSamples.Initialize", -1, content_samples_depth);
        postcontent_trace_armed = 1;
        write_text(POSTCONTENTFILE, "POSTCONTENT_ARMED after ContentSamples.Initialize\n");
        return;
    }

    if (method_is(method, "Terraria", "NPC", "SetDefaults")) {
        deep_trace_line("LEAVE", method);
        if (npc_setdefaults_depth > 0) npc_setdefaults_depth--;
        if (npc_setdefaults_depth == 0) {
            if (should_log_entity_seq(npc_setdefaults_top_seq))
                write_defaults_sequence("NPC", "TOP_LEAVE", npc_setdefaults_top_seq, npc_setdefaults_current_id, 0);
            write_state_line("TOP_LEAVE", "NPC", npc_setdefaults_current_id, 0);
        }
        return;
    }

    if (method_is(method, "Terraria", "Projectile", "SetDefaults")) {
        if (projectile_setdefaults_depth > 0) projectile_setdefaults_depth--;
        if (projectile_setdefaults_depth == 0) {
            if (should_log_entity_seq(projectile_setdefaults_top_seq))
                write_defaults_sequence("PROJECTILE", "TOP_LEAVE", projectile_setdefaults_top_seq, projectile_setdefaults_current_id, 0);
            write_state_line("TOP_LEAVE", "PROJECTILE", projectile_setdefaults_current_id, 0);
        }
        return;
    }

    if (method_is(method, "Terraria", "Item", "SetDefaults")) {
        if (item_setdefaults_depth > 0) item_setdefaults_depth--;
        if (item_setdefaults_depth == 0) {
            if (should_log_entity_seq(item_setdefaults_top_seq))
                write_defaults_sequence("ITEM", "TOP_LEAVE", item_setdefaults_top_seq, item_setdefaults_current_id, 0);
            write_state_line("TOP_LEAVE", "ITEM", item_setdefaults_current_id, 0);
        }
        return;
    }

    if (method_is(method, "Terraria.ID", "SetFactory", "<.ctor>b__31_0")) {
        if (setfactory_getname_calls <= 16 || (setfactory_getname_calls % 128) == 0)
            write_text(LOGFILE, "SETFACTORY_CTOR_LAMBDA_LEAVE\n");
        deep_trace_line("LEAVE", method);
        write_state_line("LEAVE", "SetFactory.ctor-lambda", npc_setdefaults_depth ? npc_setdefaults_current_id : (projectile_setdefaults_depth ? projectile_setdefaults_current_id : item_setdefaults_current_id), 0);
        return;
    }

    deep_trace_line("LEAVE", method);
    startup_trace_line("LEAVE", method);
}

static void startup_profiler_exception_leave(void *prof, void *method, void *exc) {
    if (post_texture_upload_armed && loadcontent_method_selected(method))
        write_loadcontent_event("EXCEPTION_LEAVE", method);
    if (display_method_selected(method)) {
        write_display_event("EXCEPTION_LEAVE", method);
        if (method_is(method, "Terraria", "Main", "SaveSettings") && save_settings_active > 0) save_settings_active--;
        if (method_is(method, "Terraria", "Main", "InitTargets") && init_targets_active > 0) init_targets_active--;
        if ((method_is(method, "Terraria", "Main", "LoadSettings") ||
             method_is(method, "Terraria", "Main", "SetDisplayMode") ||
             method_is(method, "Terraria", "Main", "InitTargets") ||
             method_is(method, "Terraria", "Main", "SaveSettings")) && display_trace_active > 0)
            display_trace_active--;
    }
    if (postcontent_trace_armed && postcontent_method_selected(method))
        write_postcontent_event("EXCEPTION_LEAVE", method);
    if (method == g_npcid_draw_offset_creation_method) {
        write_bestiary_event("DRAW_EXCEPTION_LEAVE", method);
    } else if (npcid_bestiary_method_selected(method)) {
        write_bestiary_event("HELPER_EXCEPTION_LEAVE", method);
    }
    (void)prof; (void)exc;
    if (method == g_npcid_sets_cctor_method) {
        write_text(LOGFILE, "NPCID_SETS_CCTOR_EXCEPTION_LEAVE\n");
        write_npcid_progress("NPCID_SETS_CCTOR_EXCEPTION_LEAVE", method);
        npcid_sets_cctor_active = 0;
    }
    deep_trace_line("EXCEPTION_LEAVE", method);
    startup_trace_line("EXCEPTION_LEAVE", method);
    if (method_is(method, "Terraria", "NPC", "SetDefaults"))
        write_state_line("EXCEPTION_LEAVE", "NPC", npc_setdefaults_current_id, npc_setdefaults_depth);
    else if (method_is(method, "Terraria", "Projectile", "SetDefaults"))
        write_state_line("EXCEPTION_LEAVE", "PROJECTILE", projectile_setdefaults_current_id, projectile_setdefaults_depth);
    else if (method_is(method, "Terraria", "Item", "SetDefaults"))
        write_state_line("EXCEPTION_LEAVE", "ITEM", item_setdefaults_current_id, item_setdefaults_depth);
    else if (method_is(method, "Terraria.ID", "ContentSamples", "Initialize"))
        write_state_line("EXCEPTION_LEAVE", "ContentSamples.Initialize", -1, content_samples_depth);
    else if (method_is(method, "Terraria.ID", "SetFactory", "<.ctor>b__31_0"))
        write_state_line("EXCEPTION_LEAVE", "SetFactory.ctor-lambda", npc_setdefaults_depth ? npc_setdefaults_current_id : (projectile_setdefaults_depth ? projectile_setdefaults_current_id : item_setdefaults_current_id), 0);
}

#define FIELD_ATTRIBUTE_STATIC 0x0010
#define MONO_TYPE_STRING 0x0e
#define MONO_TYPE_CLASS 0x12
#define MONO_TYPE_ARRAY 0x14
#define MONO_TYPE_GENERICINST 0x15
#define MONO_TYPE_OBJECT 0x1c
#define MONO_TYPE_SZARRAY 0x1d

static int hex_nibble(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static unsigned long parse_hex_addr(const char **pp) {
    const char *p = *pp;
    unsigned long value = 0;
    int n;
    while ((n = hex_nibble(*p)) >= 0) {
        value = (value << 4) | (unsigned long)n;
        p++;
    }
    *pp = p;
    return value;
}

static unsigned long canonical_process_address(void *address) {
#if defined(__aarch64__)
    return ((unsigned long)address) & 0x00fffffffffffffful;
#else
    return (unsigned long)address;
#endif
}

static int query_memory_protection(void *address) {
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    unsigned long target = canonical_process_address(address);
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        const char *p = line;
        unsigned long start = parse_hex_addr(&p);
        if (*p != '-') continue;
        p++;
        unsigned long end = parse_hex_addr(&p);
        while (*p == ' ') p++;
        if (target < start || target >= end) continue;
        int prot = 0;
        if (p[0] == 'r') prot |= PROT_READ;
        if (p[1] == 'w') prot |= PROT_WRITE;
        if (p[2] == 'x') prot |= PROT_EXEC;
        fclose(f);
        return prot;
    }
    fclose(f);
    return 0;
}

static void format_memory_protection(int prot, char out[4]) {
    out[0] = (prot & PROT_READ) ? 'r' : '-';
    out[1] = (prot & PROT_WRITE) ? 'w' : '-';
    out[2] = (prot & PROT_EXEC) ? 'x' : '-';
    out[3] = 0;
}

static int is_reference_type(void *mono_type, int type) {
    /* GENERICINST includes structs (Nullable<T>, KeyValuePair<K,V>, etc.).
       Never copy a value type into a pointer-sized diagnostic slot. */
    if (type == MONO_TYPE_GENERICINST)
        return g_type_is_reference ? g_type_is_reference(mono_type) : 0;
    return type == MONO_TYPE_STRING || type == MONO_TYPE_CLASS ||
           type == MONO_TYPE_ARRAY ||
           type == MONO_TYPE_OBJECT || type == MONO_TYPE_SZARRAY;
}

static void snapshot_reference_fields(void *domain, void *klass, void *object,
                                      char *out, int cap, int *ref_total, int *ref_set) {
    out[0] = 0;
    *ref_total = 0;
    *ref_set = 0;
    if (!g_class_get_fields || !g_field_get_name || !g_field_get_flags ||
        !g_field_get_type || !g_type_get_type || !g_field_get_value ||
        !g_field_static_get_value || !g_class_vtable) {
        snprintf(out, (size_t)cap, "<field APIs unavailable>");
        return;
    }

    void *vtable = g_class_vtable(domain, klass);
    void *iter = 0;
    void *field = 0;
    int shown = 0;
    while ((field = g_class_get_fields(klass, &iter)) != 0) {
        void *ftype = g_field_get_type(field);
        if (!ftype) continue;
        int etype = g_type_get_type(ftype);
        if (!is_reference_type(ftype, etype)) continue;

        unsigned int flags = g_field_get_flags(field);
        const char *name = g_field_get_name(field);
        void *value = 0;
        int is_static = (flags & FIELD_ATTRIBUTE_STATIC) != 0;
        if (is_static) {
            if (!vtable) continue;
            g_field_static_get_value(vtable, field, &value);
        } else {
            g_field_get_value(object, field, &value);
        }

        (*ref_total)++;
        if (value) (*ref_set)++;
        if (shown < 24) {
            size_t used = strlen(out);
            if (used + 96 < (size_t)cap) {
                snprintf(out + used, (size_t)cap - used, "%s%s:%s=%s",
                         used ? ", " : "", is_static ? "S" : "I",
                         name ? name : "<unnamed>", value ? "set" : "null");
                shown++;
            }
        }
    }
    if (!out[0]) snprintf(out, (size_t)cap, "<no reference fields declared>");
}

static void append_static_field_status(void *domain, void *klass, const char *field_name, char *out, size_t cap) {
    if (!out || cap == 0 || !field_name) return;
    size_t used = strlen(out);
    if (used + 96 >= cap) return;
    if (!klass || !g_find_field || !g_class_vtable || !g_field_static_get_value) {
        snprintf(out + used, cap - used, "%s=<api/class unavailable>\n", field_name);
        return;
    }
    void *field = g_find_field(klass, field_name);
    if (!field) {
        snprintf(out + used, cap - used, "%s=<field missing>\n", field_name);
        return;
    }
    void *vtable = g_class_vtable(domain, klass);
    if (!vtable) {
        snprintf(out + used, cap - used, "%s=<vtable null>\n", field_name);
        return;
    }
    void *value = 0;
    g_field_static_get_value(vtable, field, &value);
    snprintf(out + used, cap - used, "%s=%s ptr=0x%lx\n", field_name, value ? "SET" : "NULL", (unsigned long)value);
}

static void write_text(const char *path, const char *text) {
    FILE *f = fopen(path, "ab");
    if (!f) return;
    fwrite(text, 1, strlen(text), f);
    fclose(f);
}

static void write_state_line(const char *event, const char *entity, int id, int depth) {
    char line[768];
    diagnostic_event_seq++;
    snprintf(line, sizeof(line),
             "eventSeq=%d event=%s entity=%s id=%d depth=%d contentSamplesDepth=%d npcSeq=%d npcId=%d npcDepth=%d projectileSeq=%d projectileId=%d projectileDepth=%d itemSeq=%d itemId=%d itemDepth=%d\n",
             diagnostic_event_seq,
             event ? event : "<null>", entity ? entity : "<null>", id, depth,
             content_samples_depth,
             npc_setdefaults_top_seq, npc_setdefaults_current_id, npc_setdefaults_depth,
             projectile_setdefaults_top_seq, projectile_setdefaults_current_id, projectile_setdefaults_depth,
             item_setdefaults_top_seq, item_setdefaults_current_id, item_setdefaults_depth);
    FILE *f = fopen(STATEFILE, "wb");
    if (!f) return;
    fwrite(line, 1, strlen(line), f);
    fclose(f);
}

static void write_npcid_progress(const char *event, void *method) {
    char line[1536];
    const char *ns = "";
    const char *cn = "";
    const char *mn = "";
    unsigned int token = 0;
    if (method && g_method_get_class && g_method_get_name) {
        void *klass = g_method_get_class(method);
        if (klass) {
            ns = g_class_namespace ? g_class_namespace(klass) : "";
            cn = g_class_name ? g_class_name(klass) : "";
        }
        mn = g_method_get_name(method);
        if (g_method_get_token) token = g_method_get_token(method);
    }
    snprintf(line, sizeof(line),
             "event=%s cctorActive=%d cctorCompleted=%d dictAdds=%d listAdds=%d npcSeq=%d npcId=%d npcDepth=%d lastToken=0x%08x last=%s.%s::%s\n",
             event ? event : "<null>", npcid_sets_cctor_active, npcid_sets_cctor_completed,
             npc65_dictionary_adds, npc65_list_adds,
             npc_setdefaults_top_seq, npc_setdefaults_current_id, npc_setdefaults_depth,
             token, ns ? ns : "", cn ? cn : "", mn ? mn : "");
    FILE *f = fopen(PROGRESSFILE, "wb");
    if (!f) return;
    fwrite(line, 1, strlen(line), f);
    fclose(f);
}

/* Read Exception's backing fields; do not execute ToString/Message getters or
   stack-trace hooks while handling the original failure. Limit inner depth. */
static void exception_summary(void *exc, char *out, size_t cap) {
    out[0] = 0;
    for (int depth = 0; exc && depth < 4; depth++) {
        void *klass = g_object_class ? g_object_class(exc) : 0;
        const char *ns = klass && g_class_namespace ? g_class_namespace(klass) : "";
        const char *name = klass && g_class_name ? g_class_name(klass) : "<unknown>";
        size_t used = strlen(out);
        if (used + 64 >= cap) break;
        snprintf(out + used, cap - used, "%s%s.%s", depth ? " -> " : "",
                 ns ? ns : "", name ? name : "<unknown>");
        if (!g_parent_class || !g_find_field || !g_field_get_value) break;
        void *base = klass;
        int found_exception_base = 0;
        for (int n = 0; base && n < 32; n++, base = g_parent_class(base)) {
            const char *bn = g_class_name ? g_class_name(base) : 0;
            const char *bns = g_class_namespace ? g_class_namespace(base) : 0;
            if (bn && bns && !strcmp(bn, "Exception") && !strcmp(bns, "System")) { found_exception_base = 1; break; }
        }
        if (!found_exception_base) break;
        void *field = g_find_field(base, "_message");
        void *message = 0;
        if (field) g_field_get_value(exc, field, &message);
        if (message && g_string_utf8 && g_mono_free) {
            char *utf8 = g_string_utf8(message);
            if (utf8) {
                used = strlen(out);
                if (used + 3 < cap) snprintf(out + used, cap - used, ": %s", utf8);
                g_mono_free(utf8);
            }
        }
        field = g_find_field(base, "_innerException");
        void *inner = 0;
        if (field) g_field_get_value(exc, field, &inner);
        if (inner == exc) break;
        exc = inner;
    }
}

static void exception_full_text(void *exc, char *out, size_t cap) {
    if (!out || cap == 0) return;
    out[0] = 0;
    if (!exc) {
        snprintf(out, cap, "<null exception>");
        return;
    }

    int trace_was_enabled = startup_trace_enabled;
    startup_trace_enabled = 0;

    void *klass = g_object_class ? g_object_class(exc) : 0;
    void *method = 0;
    void *search = klass;
    for (int depth = 0; search && depth < 32 && !method; depth++) {
        if (g_class_get_method_from_name)
            method = g_class_get_method_from_name(search, "ToString", 0);
        search = g_parent_class ? g_parent_class(search) : 0;
    }

    if (method && g_invoke && g_string_utf8 && g_mono_free) {
        void *nested_exc = 0;
        void *managed_string = g_invoke(method, exc, 0, &nested_exc);
        if (!nested_exc && managed_string) {
            char *utf8 = g_string_utf8(managed_string);
            if (utf8) {
                snprintf(out, cap, "%s", utf8);
                g_mono_free(utf8);
            }
        }
    }

    if (!out[0])
        exception_summary(exc, out, cap);

    startup_trace_enabled = trace_was_enabled;
}

static void *invoke_with_diagnostics(void *method, void *object, void **args, void **exc) {
    void *result = g_invoke(method, object, args, exc);
    if (exc && *exc) {
        char detail[4096];
        exception_summary(*exc, detail, sizeof(detail));
        write_text(LOGFILE, "MANAGED_EXCEPTION_DETAILS=");
        write_text(LOGFILE, detail);
        write_text(LOGFILE, "\n");
    }
    return result;
}

static int read_text(const char *path, char *buf, int cap) {
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    size_t n = fread(buf, 1, (size_t)(cap - 1), f);
    int overflow = fgetc(f) != -1;
    int io_error = ferror(f);
    fclose(f);
    if (overflow || io_error) { buf[0] = 0; return 0; }
    buf[n] = 0;
    while (n > 0 && (buf[n - 1] == '\n' || buf[n - 1] == '\r' || buf[n - 1] == ' ' || buf[n - 1] == '\t')) {
        buf[n - 1] = 0;
        n--;
    }
    return n > 0;
}

static int file_exists(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    fclose(f);
    return 1;
}

static int content_canary_state(const char *content_root, int *has_651, int *has_981) {
    char path_651[1600];
    char path_981[1600];
    int n1 = snprintf(path_651, sizeof(path_651), "%s/Images/Projectile_651.xnb", content_root);
    int n2 = snprintf(path_981, sizeof(path_981), "%s/Images/Projectile_981.xnb", content_root);
    if (n1 < 0 || n2 < 0 || (size_t)n1 >= sizeof(path_651) || (size_t)n2 >= sizeof(path_981)) return 0;
    *has_651 = file_exists(path_651);
    *has_981 = file_exists(path_981);
    return 1;
}

static int prepare_android_content_cwd(void) {
    const char *internal = SDL_AndroidGetInternalStoragePath();
    char content_root[1500];
    int h651 = 0;
    int h981 = 0;

    if (internal && internal[0]) {
        int n = snprintf(content_root, sizeof(content_root), "%s/Content", internal);
        if (n > 0 && (size_t)n < sizeof(content_root) && content_canary_state(content_root, &h651, &h981)) {
            if (h651 && h981) {
                if (chdir(private_dir) != 0) return 0;
                write_text(LOGFILE, "ANDROID_CONTENT_SOURCE=PRIVATE_FILES_CONTENT; cwd=private monovm directory so upstream ../Content resolves to the NativeAOT-era files/Content tree.\n");
                return 1;
            }
            if (h651 || h981) {
                snprintf(report, sizeof(report), "ANDROID_CONTENT_CANDIDATE=PRIVATE_FILES_CONTENT incomplete canaries: Projectile_651=%s Projectile_981=%s\n", h651 ? "YES" : "NO", h981 ? "YES" : "NO");
                write_text(LOGFILE, report);
            }
        }
    }

    snprintf(content_root, sizeof(content_root), "%s/Content", BASE);
    h651 = h981 = 0;
    if (content_canary_state(content_root, &h651, &h981)) {
        if (h651 && h981) {
            if (chdir(WORK_DIR) != 0) return 0;
            write_text(LOGFILE, "ANDROID_CONTENT_SOURCE=EXTERNAL_BASE_CONTENT; cwd=BASE/work so upstream ../Content resolves to BASE/Content.\n");
            return 1;
        }
        if (h651 || h981) {
            snprintf(report, sizeof(report), "ANDROID_CONTENT_CANDIDATE=EXTERNAL_BASE_CONTENT incomplete canaries: Projectile_651=%s Projectile_981=%s\n", h651 ? "YES" : "NO", h981 ? "YES" : "NO");
            write_text(LOGFILE, report);
        }
    }

    snprintf(content_root, sizeof(content_root), "%s/Terraria/Content", BASE);
    h651 = h981 = 0;
    if (content_canary_state(content_root, &h651, &h981)) {
        if (h651 && h981) {
            if (chdir(WORK_DIR) != 0) return 0;
            write_text(LOGFILE, "ANDROID_CONTENT_SOURCE=EXTERNAL_SIDE_BY_SIDE_TERRARIA_CONTENT; cwd=BASE/work so upstream ../Terraria/Content resolves to BASE/Terraria/Content.\n");
            return 1;
        }
        if (h651 || h981) {
            snprintf(report, sizeof(report), "ANDROID_CONTENT_CANDIDATE=EXTERNAL_SIDE_BY_SIDE_TERRARIA_CONTENT incomplete canaries: Projectile_651=%s Projectile_981=%s\n", h651 ? "YES" : "NO", h981 ? "YES" : "NO");
            write_text(LOGFILE, report);
        }
    }

    if (chdir(WORK_DIR) != 0) return 0;
    write_text(LOGFILE, "ANDROID_CONTENT_SOURCE=NONE; no complete vanilla Content tree with Projectile_651.xnb and Projectile_981.xnb was found in private files/Content, BASE/Content, or BASE/Terraria/Content. Upstream tModLoader content validation will report the next boundary.\n");
    return 1;
}

static int copy_file(const char *src, const char *dst) {
    char tmp[1500];
    int len = snprintf(tmp, sizeof(tmp), "%s.tmp", dst);
    if (len < 0 || (size_t)len >= sizeof(tmp)) return 0;
    FILE *in = fopen(src, "rb");
    if (!in) return 0;
    FILE *out = fopen(tmp, "wb");
    if (!out) { fclose(in); return 0; }
    char buf[65536];
    int ok = 1;
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0) {
        if (fwrite(buf, 1, n, out) != n) { ok = 0; break; }
    }
    if (ferror(in)) ok = 0;
    if (fclose(out) != 0) ok = 0;
    if (fclose(in) != 0) ok = 0;
    if (ok && rename(tmp, dst) != 0) ok = 0;
    if (!ok) remove(tmp);
    return ok;
}

static int valid_native_name(const char *name) {
    size_t n = strlen(name);
    if (n < 4 || name[0] == '.' || strcmp(name + n - 3, ".so")) return 0;
    for (size_t i = 0; i < n; i++) {
        char c = name[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.')) return 0;
    }
    return 1;
}

static void append_requested(const char *name) {
    if (!name || !name[0]) return;
    size_t used = strlen(requested_assemblies);
    size_t need = strlen(name) + (used ? 2 : 0) + 1;
    if (used + need >= sizeof(requested_assemblies)) return;
    snprintf(requested_assemblies + used, sizeof(requested_assemblies) - used, "%s%s", used ? ", " : "", name);
}

static void *assembly_preload_probe(void *aname, char **assemblies_path, void *user_data) {
    (void)assemblies_path;
    (void)user_data;
    preload_calls++;
    if (g_assembly_name_get_name && aname) append_requested(g_assembly_name_get_name(aname));
    return 0;
}

static void checkpoint(const char *step) {
    snprintf(report, sizeof(report),
        "BUILD=Phase2.22.98 BootstrapFix18.22\nSTEP=%s\n"
        "BASE=%s\nPrivateNative=%s\nNativeStaged=%d\n"
        "tModLoaderPresent=%s\nConfigManagerPresent=%s\nPreloadCalls=%d\nRequested=%s\n"
        "Runtime=8.0.23\nRID=android-arm64\n",
        step, BASE, private_dir[0] ? private_dir : "<not-ready>", native_staged,
        file_exists(TML) ? "YES" : "NO", file_exists(CONFIGMGR) ? "YES" : "NO", preload_calls,
        requested_assemblies[0] ? requested_assemblies : "<none>");
    write_text(LOGFILE, report);
}

static int fail(const char *step, const char *detail, int code) {
    snprintf(report, sizeof(report),
        "MonoVM Phase 2.22.98 BootstrapFix18.22 falhou em %s\n\n%s\n\n"
        "BASE=%s\nPrivateNative=%s\nNativeStaged=%d\n"
        "tModLoaderPresent=%s\nConfigManagerPresent=%s\nPreloadCalls=%d\nRequested=%s\n"
        "Runtime=8.0.23\nRID=android-arm64\n",
        step, detail ? detail : "sem detalhe", BASE,
        private_dir[0] ? private_dir : "<not-ready>", native_staged,
        file_exists(TML) ? "YES" : "NO", file_exists(CONFIGMGR) ? "YES" : "NO", preload_calls,
        requested_assemblies[0] ? requested_assemblies : "<none>");
    write_text(LOGFILE, report);
    SDL_ShowSimpleMessageBox(0x10, "tML Android MonoVM", report, 0);
    return code;
}

#include "graphics_binding.inc"

static int stage_native_runtime(void) {
    const char *internal = SDL_AndroidGetInternalStoragePath();
    if (!internal || !internal[0]) return 0;
    snprintf(private_dir, sizeof(private_dir), "%s/monovm", internal);
    mkdir(private_dir, 0700);
    if (!clear_stale_graphics_copies()) return 0;

    FILE *f = fopen(NATIVE_LIST, "rb");
    if (!f) return 0;
    char name[256];
    char src[1400];
    char dst[1400];
    native_staged = 0;
    while (fgets(name, sizeof(name), f)) {
        size_t n = strlen(name);
        while (n > 0 && (name[n - 1] == '\n' || name[n - 1] == '\r' || name[n - 1] == ' ' || name[n - 1] == '\t')) {
            name[n - 1] = 0;
            n--;
        }
        if (!name[0]) continue;
        if (!valid_native_name(name) || n >= sizeof(name) - 1) { fclose(f); return 0; }
        if (graphics_alias_kind(name)) continue; /* The APK owns these libraries. */
        snprintf(src, sizeof(src), "%s/%s", RUNTIME, name);
        snprintf(dst, sizeof(dst), "%s/%s", private_dir, name);
        if (!copy_file(src, dst)) {
            fclose(f);
            return 0;
        }
        native_staged++;
    }
    int list_error = ferror(f);
    fclose(f);
    if (list_error) return 0;
    snprintf(private_mono, sizeof(private_mono), "%s/libmonosgen-2.0.so", private_dir);
    return native_staged > 0 && file_exists(private_mono);
}

static int phase2_22_90_main_impl(int argc, char **argv) {
    (void)argc;
    (void)argv;
    mkdir(BASE, 0770);
    /* Preserve the previous run and retain every checkpoint of this run. */
    char previous_log[1400];
    snprintf(previous_log, sizeof(previous_log), "%s.previous", LOGFILE);
    if (file_exists(LOGFILE) && rename(LOGFILE, previous_log) != 0)
        return fail("log-rotation", "nao foi possivel preservar o log anterior.", 68);
    if (file_exists(STATEFILE))
        remove(STATEFILE);
    if (file_exists(DEEPFILE))
        remove(DEEPFILE);
    if (file_exists(PROGRESSFILE))
        remove(PROGRESSFILE);
    if (file_exists(JITFILE))
        remove(JITFILE);
    mkdir(DEPS, 0770);
    mkdir(WORK_DIR, 0770);
    mkdir(LOG_DIR_ABS, 0770);
    if (chdir(WORK_DIR) != 0) return fail("working-directory-chdir", "nao foi possivel entrar no diretorio de trabalho gravavel do app.", 69);
    private_dir[0] = 0;
    requested_assemblies[0] = 0;
    preload_calls = 0;
    checkpoint("working-directory-ready");

    if (!file_exists(TPA)) return fail("tpa-check", "tpa.paths nao encontrado.", 70);
    if (!file_exists(NATIVE_LIST)) return fail("native-list-check", "native.list nao encontrado.", 71);
    if (!file_exists(SPLIT_TMOD_MODPATH)) return fail("split-tmod-modpath-check", "Split.tmod nao encontrado na pasta Mods real do tModLoader.", 72);
    if (!file_exists(ENABLED_JSON)) return fail("enabled-json-check", "enabled.json nao encontrado na pasta Mods real do tModLoader.", 72);
    if (!read_text(TPA, tpa_buf, (int)sizeof(tpa_buf))) return fail("tpa-read", "tpa.paths vazio ou ilegivel.", 73);

    checkpoint("before-native-runtime-staging");
    if (!stage_native_runtime()) return fail("native-runtime-staging", "nao foi possivel preparar o runtime nativo privado.", 74);
    checkpoint("native-runtime-staged");

    void *mono = dlopen(private_mono, RTLD_NOW | RTLD_GLOBAL);
    if (!mono) {
        const char *e = dlerror();
        return fail("dlopen-private-libmonosgen", e ? e : "dlopen retornou nulo.", 75);
    }

#define RESOLVE(name, type, var) \
    type var = (type)dlsym(mono, name); \
    if (!(var)) { dlclose(mono); return fail("dlsym-" name, "Mono API obrigatoria nao exportada.", 76); }

    typedef int (*monovm_initialize_t)(int, const char **, const char **);
    typedef void (*mono_set_assemblies_path_t)(const char *);
    typedef void (*mono_jit_set_aot_mode_t)(int);
    typedef void *(*mono_jit_init_version_t)(const char *, const char *);
    typedef void *(*mono_domain_assembly_open_t)(void *, const char *);
    typedef void *(*mono_assembly_get_image_t)(void *);
    typedef const char *(*mono_image_get_name_t)(void *);
    typedef void *(*mono_class_from_name_t)(void *, const char *, const char *);
    typedef const char *(*mono_class_get_name_t)(void *);
    typedef const char *(*mono_class_get_namespace_t)(void *);
    typedef void *(*mono_class_get_parent_t)(void *);
    typedef int (*mono_class_init_t)(void *);
    typedef void *(*mono_object_new_t)(void *, void *);
    typedef void *(*mono_class_get_method_from_name_t)(void *, const char *, int);
    typedef void *(*mono_class_get_field_from_name_t)(void *, const char *);
    typedef void (*mono_field_static_set_value_t)(void *, void *, void *);
    typedef void *(*mono_string_new_t)(void *, const char *);
    typedef void *(*mono_runtime_invoke_t)(void *, void *, void **, void **);
    typedef void *(*mono_object_get_class_t)(void *);
    typedef int (*mono_class_is_subclass_of_t)(void *, void *, int);
    typedef void *(*mono_method_get_class_t)(void *);
    typedef const char *(*mono_method_get_name_t)(void *);
    typedef void *(*mono_class_get_fields_t)(void *, void **);
    typedef const char *(*mono_field_get_name_t)(void *);
    typedef unsigned int (*mono_field_get_flags_t)(void *);
    typedef void *(*mono_field_get_type_t)(void *);
    typedef int (*mono_type_get_type_t)(void *);
    typedef void *(*mono_class_vtable_t)(void *, void *);
    typedef void (*mono_field_get_value_t)(void *, void *, void *);
    typedef void (*mono_field_static_get_value_t)(void *, void *, void *);
    typedef void (*mono_install_assembly_preload_hook_t)(void *(*)(void *, char **, void *), void *);
    typedef void (*mono_field_set_value_t)(void *, void *, void *);
    typedef void (*mono_add_internal_call_t)(const char *, const void *);
    typedef unsigned int (*mono_method_get_token_t)(void *);
    typedef const void *(*mono_image_get_table_info_t)(void *, int);
    typedef unsigned int (*mono_metadata_decode_row_col_t)(const void *, int, unsigned int);
    typedef void *(*mono_image_rva_map_t)(void *, unsigned int);

    RESOLVE("monovm_initialize", monovm_initialize_t, monovm_initialize);
    RESOLVE("mono_set_assemblies_path", mono_set_assemblies_path_t, mono_set_assemblies_path);
    RESOLVE("mono_jit_set_aot_mode", mono_jit_set_aot_mode_t, mono_jit_set_aot_mode);
    RESOLVE("mono_jit_init_version", mono_jit_init_version_t, mono_jit_init_version);
    RESOLVE("mono_domain_assembly_open", mono_domain_assembly_open_t, mono_domain_assembly_open);
    RESOLVE("mono_assembly_get_image", mono_assembly_get_image_t, mono_assembly_get_image);
    RESOLVE("mono_image_get_name", mono_image_get_name_t, mono_image_get_name);
    RESOLVE("mono_class_from_name", mono_class_from_name_t, mono_class_from_name);
    RESOLVE("mono_class_get_name", mono_class_get_name_t, mono_class_get_name);
    RESOLVE("mono_class_get_namespace", mono_class_get_namespace_t, mono_class_get_namespace);
    RESOLVE("mono_class_get_parent", mono_class_get_parent_t, mono_class_get_parent);
    RESOLVE("mono_class_init", mono_class_init_t, mono_class_init);
    RESOLVE("mono_object_new", mono_object_new_t, mono_object_new);
    RESOLVE("mono_class_get_method_from_name", mono_class_get_method_from_name_t, mono_class_get_method_from_name);
    RESOLVE("mono_class_get_field_from_name", mono_class_get_field_from_name_t, mono_class_get_field_from_name);
    RESOLVE("mono_field_static_set_value", mono_field_static_set_value_t, mono_field_static_set_value);
    RESOLVE("mono_string_new", mono_string_new_t, mono_string_new);
    RESOLVE("mono_runtime_invoke", mono_runtime_invoke_t, mono_runtime_invoke);
    RESOLVE("mono_object_get_class", mono_object_get_class_t, mono_object_get_class);
    RESOLVE("mono_class_is_subclass_of", mono_class_is_subclass_of_t, mono_class_is_subclass_of);
    RESOLVE("mono_method_get_class", mono_method_get_class_t, mono_method_get_class);
    RESOLVE("mono_method_get_name", mono_method_get_name_t, mono_method_get_name);
    g_method_get_class = mono_method_get_class;
    g_method_get_name = mono_method_get_name;
    g_class_get_method_from_name = mono_class_get_method_from_name;
    RESOLVE("mono_add_internal_call", mono_add_internal_call_t, mono_add_internal_call);
    RESOLVE("mono_method_get_token", mono_method_get_token_t, mono_method_get_token);
    g_method_get_token = mono_method_get_token;
    RESOLVE("mono_image_get_table_info", mono_image_get_table_info_t, mono_image_get_table_info);
    RESOLVE("mono_metadata_decode_row_col", mono_metadata_decode_row_col_t, mono_metadata_decode_row_col);
    RESOLVE("mono_image_rva_map", mono_image_rva_map_t, mono_image_rva_map);
    mono_class_get_fields_t mono_class_get_fields = (mono_class_get_fields_t)dlsym(mono, "mono_class_get_fields");
    mono_field_get_name_t mono_field_get_name = (mono_field_get_name_t)dlsym(mono, "mono_field_get_name");
    mono_field_get_flags_t mono_field_get_flags = (mono_field_get_flags_t)dlsym(mono, "mono_field_get_flags");
    mono_field_get_type_t mono_field_get_type = (mono_field_get_type_t)dlsym(mono, "mono_field_get_type");
    mono_type_get_type_t mono_type_get_type = (mono_type_get_type_t)dlsym(mono, "mono_type_get_type");
    mono_class_vtable_t mono_class_vtable = (mono_class_vtable_t)dlsym(mono, "mono_class_vtable");
    mono_field_get_value_t mono_field_get_value = (mono_field_get_value_t)dlsym(mono, "mono_field_get_value");
    mono_field_static_get_value_t mono_field_static_get_value = (mono_field_static_get_value_t)dlsym(mono, "mono_field_static_get_value");

    g_class_get_fields = mono_class_get_fields;
    g_field_get_name = mono_field_get_name;
    g_field_get_flags = mono_field_get_flags;
    g_field_get_type = mono_field_get_type;
    g_type_get_type = mono_type_get_type;
    g_type_is_reference = (int (*)(void *))dlsym(mono, "mono_type_is_reference");
    g_class_vtable = mono_class_vtable;
    g_field_get_value = mono_field_get_value;
    g_field_static_get_value = mono_field_static_get_value;


    typedef void *(*mono_method_desc_new_t)(const char *, int);
    typedef void *(*mono_method_desc_search_in_class_t)(void *, void *);
    typedef void (*mono_method_desc_free_t)(void *);
    typedef void *(*mono_assembly_get_object_t)(void *, void *);
    mono_method_desc_new_t mono_method_desc_new = (mono_method_desc_new_t)dlsym(mono, "mono_method_desc_new");
    mono_method_desc_search_in_class_t mono_method_desc_search_in_class = (mono_method_desc_search_in_class_t)dlsym(mono, "mono_method_desc_search_in_class");
    mono_method_desc_free_t mono_method_desc_free = (mono_method_desc_free_t)dlsym(mono, "mono_method_desc_free");
    mono_assembly_get_object_t mono_assembly_get_object = (mono_assembly_get_object_t)dlsym(mono, "mono_assembly_get_object");
    mono_field_set_value_t mono_field_set_value = (mono_field_set_value_t)dlsym(mono, "mono_field_set_value");
    typedef void *(*mono_class_get_nested_types_t)(void *, void **);
    mono_class_get_nested_types_t mono_class_get_nested_types = (mono_class_get_nested_types_t)dlsym(mono, "mono_class_get_nested_types");

    mono_install_assembly_preload_hook_t mono_install_assembly_preload_hook =
        (mono_install_assembly_preload_hook_t)dlsym(mono, "mono_install_assembly_preload_hook");
    g_assembly_name_get_name = (const char *(*)(void *))dlsym(mono, "mono_assembly_name_get_name");

    g_invoke = mono_runtime_invoke;
    g_object_class = mono_object_get_class;
    g_parent_class = mono_class_get_parent;
    g_class_name = mono_class_get_name;
    g_class_namespace = mono_class_get_namespace;
    g_find_field = mono_class_get_field_from_name;
    g_string_utf8 = (char *(*)(void *))dlsym(mono, "mono_string_to_utf8");
    g_mono_free = (void (*)(void *))dlsym(mono, "mono_free");
    #define mono_runtime_invoke invoke_with_diagnostics

    checkpoint("before-shared-graphics-binding");
    if (!install_graphics_binding(mono))
        return fail("shared-graphics-binding", "SDL/FNA3D do APK nao puderam ser vinculadas ao Mono. Consulte GRAPHICS_ERROR no log.", 144);
    checkpoint("shared-graphics-binding-ready");
    checkpoint("mono-api-ok");
    snprintf(assembly_paths, sizeof(assembly_paths), "%s:%s", RUNTIME, DEPS);
    mono_set_assemblies_path(assembly_paths);

    char pinvoke_override_value[64];
    snprintf(pinvoke_override_value, sizeof(pinvoke_override_value), "0x%lx",
             (unsigned long)graphics_pinvoke_override);

    const char *keys[6];
    const char *values[6];
    keys[0] = "RUNTIME_IDENTIFIER";
    values[0] = "android-arm64";
    keys[1] = "APP_CONTEXT_BASE_DIRECTORY";
    values[1] = RUNTIME;
    keys[2] = "APP_PATHS";
    values[2] = assembly_paths;
    keys[3] = "NATIVE_DLL_SEARCH_DIRECTORIES";
    values[3] = private_dir;
    keys[4] = "TRUSTED_PLATFORM_ASSEMBLIES";
    values[4] = tpa_buf;
    keys[5] = "PINVOKE_OVERRIDE";
    values[5] = pinvoke_override_value;

    write_text(LOGFILE, "PINVOKE_OVERRIDE_PROPERTY=");
    write_text(LOGFILE, pinvoke_override_value);
    write_text(LOGFILE, "\n");
    checkpoint("pinvoke-override-runtime-property-ready");

    checkpoint("before-monovm-initialize");
    int init_rc = monovm_initialize(6, keys, values);
    if (init_rc != 0) {
        char detail[160];
        snprintf(detail, sizeof(detail), "monovm_initialize retornou %d", init_rc);
        return fail("monovm-initialize", detail, 77);
    }

    mono_jit_set_aot_mode(MONO_AOT_MODE_NORMAL);
    checkpoint("before-domain-create");
    void *domain = mono_jit_init_version("tml.android.monovm.phase22286", "mobile");
    if (!domain) {
        return fail("mono-jit-init", "dominio Mono nao foi criado.", 78);
    }
    checkpoint("domain-ready");

    checkpoint("before-sdl-createwindow-icall-register");
    mono_add_internal_call("SDL2.SDL::INTERNAL_SDL_CreateWindow",
                           (const void *)fix15_sdl_create_window_icall);
    write_text(LOGFILE, "ICALL_REGISTER=SDL2.SDL::INTERNAL_SDL_CreateWindow -> native SDL_CreateWindow bridge\n");
    checkpoint("sdl-createwindow-icall-registered");

    checkpoint("before-sdl-displaymode-icall-register");
    mono_add_internal_call("SDL2.SDL::SDL_GetDisplayMode",
                           (const void *)fix16_sdl_get_display_mode_icall);
    mono_add_internal_call("SDL2.SDL::SDL_GetCurrentDisplayMode",
                           (const void *)fix16_sdl_get_current_display_mode_icall);
    mono_add_internal_call("SDL2.SDL::SDL_GetDesktopDisplayMode",
                           (const void *)fix16_sdl_get_desktop_display_mode_icall);
    mono_add_internal_call("SDL2.SDL::SDL_GetWindowDisplayMode",
                           (const void *)fix16_sdl_get_window_display_mode_icall);
    write_text(LOGFILE, "ICALL_REGISTER=SDL2 display-mode getters -> native SDL2 bridges\n");
    checkpoint("sdl-displaymode-icall-registered");

    checkpoint("before-fix17-window-fna3d-icall-register");
    mono_add_internal_call("SDL2.SDL::SDL_GetWindowSize",
                           (const void *)fix17_sdl_get_window_size_icall);
    mono_add_internal_call("SDL2.SDL::SDL_GetWindowPosition",
                           (const void *)fix17_sdl_get_window_position_icall);
    mono_add_internal_call("SDL2.SDL::SDL_GetWindowMinimumSize",
                           (const void *)fix17_sdl_get_window_minimum_size_icall);
    mono_add_internal_call("SDL2.SDL::SDL_GetWindowMaximumSize",
                           (const void *)fix17_sdl_get_window_maximum_size_icall);
    mono_add_internal_call("SDL2.SDL::SDL_GetWindowBordersSize",
                           (const void *)fix17_sdl_get_window_borders_size_icall);
    mono_add_internal_call("SDL2.SDL::SDL_PollEvent",
                           (const void *)fix17_sdl_poll_event_icall);
    mono_add_internal_call("SDL2.SDL::SDL_SetWindowBordered",
                           (const void *)fix18_sdl_set_window_bordered_icall);
    mono_add_internal_call("SDL2.SDL::SDL_SetWindowResizable",
                           (const void *)fix18_sdl_set_window_resizable_icall);

    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_GetDrawableSize",
                           (const void *)fix17_fna3d_get_drawable_size_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_CreateDevice",
                           (const void *)fix17_fna3d_create_device_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_GetMaxTextureSlots",
                           (const void *)fix17_fna3d_get_max_texture_slots_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_GetMaxMultiSampleCount",
                           (const void *)fix19_fna3d_get_max_multisample_count_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_CreateTexture2D",
                           (const void *)fix20_fna3d_create_texture2d_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_SetTextureData2D",
                           (const void *)fix22_fna3d_set_texture_data2d_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_SetViewport",
                           (const void *)fix17_fna3d_set_viewport_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_SetScissorRect",
                           (const void *)fix17_fna3d_set_scissor_rect_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_GetBlendFactor",
                           (const void *)fix17_fna3d_get_blend_factor_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_SetBlendFactor",
                           (const void *)fix17_fna3d_set_blend_factor_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_SetBlendState",
                           (const void *)fix17_fna3d_set_blend_state_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_SetDepthStencilState",
                           (const void *)fix17_fna3d_set_depth_stencil_state_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_ApplyRasterizerState",
                           (const void *)fix17_fna3d_apply_rasterizer_state_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_VerifySampler",
                           (const void *)fix17_fna3d_verify_sampler_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_VerifyVertexSampler",
                           (const void *)fix17_fna3d_verify_vertex_sampler_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_ResolveTarget",
                           (const void *)fix17_fna3d_resolve_target_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_ResetBackbuffer",
                           (const void *)fix17_fna3d_reset_backbuffer_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_GetBackbufferSize",
                           (const void *)fix17_fna3d_get_backbuffer_size_icall);
    mono_add_internal_call("Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_Clear",
                           (const void *)fix17_fna3d_clear_icall);
    write_text(LOGFILE, "ICALL_REGISTER=Fix22 SDL window/event/bool + FNA3D bootstrap/MSAA/Texture2D upload bridges\n");
    checkpoint("fix17-window-fna3d-icall-registered");

    void *fna_asm = 0;
    void *fna_image = 0;
    if (file_exists(FNA)) {
        fna_asm = mono_domain_assembly_open(domain, FNA);
        if (!fna_asm) return fail("fna-load", "FNA.dll da baseline nao carregou.", 79);
        fna_image = mono_assembly_get_image(fna_asm);
    }
    checkpoint("fna-ready");

    write_text(BINDINGFILE, "PHASE=2.22.98\n");
    write_text(LOADCONTENTFILE, "PHASE=2.22.98\nPURPOSE=Trace the exact managed stage immediately after the proven 1x1 default texture upload in Main.LoadContent.\n");
    write_text(BINDINGFILE, "PURPOSE=Keep the proven tagged-pointer CreateTexture2D bridge and convert FNA3D_SetTextureData2D from PInvoke to InternalCall before first JIT, then audit the adjacent texture-family bindings.\n");
    if (fna_image) {
        typedef unsigned int (*mono_method_get_flags_optional_t)(void *, unsigned int *);
        typedef void *(*mono_lookup_internal_call_optional_t)(void *);
        mono_method_get_flags_optional_t opt_method_get_flags =
            (mono_method_get_flags_optional_t)dlsym(mono, "mono_method_get_flags");
        mono_lookup_internal_call_optional_t opt_lookup_internal_call =
            (mono_lookup_internal_call_optional_t)dlsym(mono, "mono_lookup_internal_call");

        void *fna3d_impl_class = mono_class_from_name(
            fna_image,
            "Microsoft.Xna.Framework.Graphics",
            "FNA3D_Impl"
        );

        if (!fna3d_impl_class) {
            write_text(BINDINGFILE, "FNA3D_IMPL_CLASS=NOT_FOUND\n");
        } else {
            write_text(BINDINGFILE, "FNA3D_IMPL_CLASS=FOUND\n");

            void *create_texture2d_method = mono_class_get_method_from_name(
                fna3d_impl_class, "FNA3D_CreateTexture2D", 6);
            if (!create_texture2d_method) {
                write_text(BINDINGFILE, "CREATETEXTURE2D_METADATA_PATCH=METHOD_NOT_FOUND\n");
            } else {
                typedef struct fix21_mono_method_header {
                    unsigned short flags;
                    unsigned short iflags;
                    unsigned int token;
                } fix21_mono_method_header;
                fix21_mono_method_header *mh = (fix21_mono_method_header *)create_texture2d_method;
                unsigned int before_iflags = 0;
                unsigned int before_flags = opt_method_get_flags ?
                    opt_method_get_flags(create_texture2d_method, &before_iflags) : mh->flags;
                char line[768];
                int prot = query_memory_protection(create_texture2d_method);
                char prot_text[4];
                format_memory_protection(prot, prot_text);
                unsigned long canonical_method = canonical_process_address(create_texture2d_method);
                snprintf(line, sizeof(line),
                         "CREATETEXTURE2D_METADATA_BEFORE method=%p canonical=0x%lx token=0x%08x flags=0x%08x implFlags=0x%08x memory=%s\n",
                         create_texture2d_method, canonical_method, mono_method_get_token(create_texture2d_method),
                         before_flags, before_iflags, prot_text);
                write_text(BINDINGFILE, line);

                int made_writable = 0;
                int mprotect_rc = -999;
                unsigned long patch_page = 0;
                int page_size = getpagesize();
                if (!(prot & PROT_WRITE) && prot) {
                    patch_page = canonical_method & ~((unsigned long)page_size - 1ul);
                    mprotect_rc = mprotect((void *)patch_page, (size_t)page_size, prot | PROT_WRITE);
                    if (mprotect_rc == 0)
                        made_writable = 1;
                }
                snprintf(line, sizeof(line),
                         "CREATETEXTURE2D_MPROTECT canonicalPage=0x%lx pageSize=%d originalProt=%d rc=%d madeWritable=%u\n",
                         patch_page, page_size, prot, mprotect_rc, made_writable ? 1u : 0u);
                write_text(BINDINGFILE, line);

                if ((prot & PROT_WRITE) || made_writable) {
                    mh->flags = (unsigned short)(mh->flags & (unsigned short)~0x2000u);
                    mh->iflags = (unsigned short)(mh->iflags | (unsigned short)0x1000u);
                    write_text(BINDINGFILE, "CREATETEXTURE2D_METADATA_PATCH=APPLIED\n");
                } else {
                    write_text(BINDINGFILE, "CREATETEXTURE2D_METADATA_PATCH=MEMORY_NOT_WRITABLE\n");
                }

                if (made_writable) {
                    int restore_rc = mprotect((void *)patch_page, (size_t)page_size, prot);
                    snprintf(line, sizeof(line),
                             "CREATETEXTURE2D_MPROTECT_RESTORE page=0x%lx prot=%d rc=%d\n",
                             patch_page, prot, restore_rc);
                    write_text(BINDINGFILE, line);
                }

                unsigned int after_iflags = 0;
                unsigned int after_flags = opt_method_get_flags ?
                    opt_method_get_flags(create_texture2d_method, &after_iflags) : mh->flags;
                snprintf(line, sizeof(line),
                         "CREATETEXTURE2D_METADATA_AFTER token=0x%08x flags=0x%08x implFlags=0x%08x pinvoke=%u internalCall=%u\n",
                         mono_method_get_token(create_texture2d_method), after_flags, after_iflags,
                         (after_flags & 0x2000u) ? 1u : 0u,
                         (after_iflags & 0x1000u) ? 1u : 0u);
                write_text(BINDINGFILE, line);
            }

            mono_add_internal_call(
                "Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_CreateTexture2D",
                (const void *)fix20_fna3d_create_texture2d_icall
            );
            mono_add_internal_call(
                "Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_CreateTexture2D(System.IntPtr,Microsoft.Xna.Framework.Graphics.SurfaceFormat,System.Int32,System.Int32,System.Int32,System.Byte)",
                (const void *)fix20_fna3d_create_texture2d_icall
            );
            write_text(BINDINGFILE, "CREATETEXTURE2D_ICALL_REREGISTER=done\n");
            if (create_texture2d_method && opt_lookup_internal_call) {
                void *resolved = opt_lookup_internal_call(create_texture2d_method);
                char line[384];
                snprintf(line, sizeof(line),
                         "CREATETEXTURE2D_LOOKUP_AFTER_PATCH=%p expectedBridge=%p match=%u\n",
                         resolved, (void *)fix20_fna3d_create_texture2d_icall,
                         resolved == (void *)fix20_fna3d_create_texture2d_icall ? 1u : 0u);
                write_text(BINDINGFILE, line);
            }

            void *set_texture_data2d_method = mono_class_get_method_from_name(
                fna3d_impl_class, "FNA3D_SetTextureData2D", 9);
            if (!set_texture_data2d_method) {
                write_text(BINDINGFILE, "SETTEXTUREDATA2D_METADATA_PATCH=METHOD_NOT_FOUND\n");
            } else {
                typedef struct fix22_mono_method_header {
                    unsigned short flags;
                    unsigned short iflags;
                    unsigned int token;
                } fix22_mono_method_header;
                fix22_mono_method_header *mh = (fix22_mono_method_header *)set_texture_data2d_method;
                unsigned int before_iflags = 0;
                unsigned int before_flags = opt_method_get_flags ?
                    opt_method_get_flags(set_texture_data2d_method, &before_iflags) : mh->flags;
                char line[768];
                int prot = query_memory_protection(set_texture_data2d_method);
                char prot_text[4];
                format_memory_protection(prot, prot_text);
                unsigned long canonical_method = canonical_process_address(set_texture_data2d_method);
                snprintf(line, sizeof(line),
                         "SETTEXTUREDATA2D_METADATA_BEFORE method=%p canonical=0x%lx token=0x%08x flags=0x%08x implFlags=0x%08x memory=%s\n",
                         set_texture_data2d_method, canonical_method, mono_method_get_token(set_texture_data2d_method),
                         before_flags, before_iflags, prot_text);
                write_text(BINDINGFILE, line);

                int made_writable = 0;
                int mprotect_rc = -999;
                unsigned long patch_page = 0;
                int page_size = getpagesize();
                if (!(prot & PROT_WRITE) && prot) {
                    patch_page = canonical_method & ~((unsigned long)page_size - 1ul);
                    mprotect_rc = mprotect((void *)patch_page, (size_t)page_size, prot | PROT_WRITE);
                    if (mprotect_rc == 0) made_writable = 1;
                }
                snprintf(line, sizeof(line),
                         "SETTEXTUREDATA2D_MPROTECT canonicalPage=0x%lx pageSize=%d originalProt=%d rc=%d madeWritable=%u\n",
                         patch_page, page_size, prot, mprotect_rc, made_writable ? 1u : 0u);
                write_text(BINDINGFILE, line);

                if ((prot & PROT_WRITE) || made_writable) {
                    mh->flags = (unsigned short)(mh->flags & (unsigned short)~0x2000u);
                    mh->iflags = (unsigned short)(mh->iflags | (unsigned short)0x1000u);
                    write_text(BINDINGFILE, "SETTEXTUREDATA2D_METADATA_PATCH=APPLIED\n");
                } else {
                    write_text(BINDINGFILE, "SETTEXTUREDATA2D_METADATA_PATCH=MEMORY_NOT_WRITABLE\n");
                }

                if (made_writable) {
                    int restore_rc = mprotect((void *)patch_page, (size_t)page_size, prot);
                    snprintf(line, sizeof(line),
                             "SETTEXTUREDATA2D_MPROTECT_RESTORE page=0x%lx prot=%d rc=%d\n",
                             patch_page, prot, restore_rc);
                    write_text(BINDINGFILE, line);
                }

                unsigned int after_iflags = 0;
                unsigned int after_flags = opt_method_get_flags ?
                    opt_method_get_flags(set_texture_data2d_method, &after_iflags) : mh->flags;
                snprintf(line, sizeof(line),
                         "SETTEXTUREDATA2D_METADATA_AFTER token=0x%08x flags=0x%08x implFlags=0x%08x pinvoke=%u internalCall=%u\n",
                         mono_method_get_token(set_texture_data2d_method), after_flags, after_iflags,
                         (after_flags & 0x2000u) ? 1u : 0u,
                         (after_iflags & 0x1000u) ? 1u : 0u);
                write_text(BINDINGFILE, line);
            }

            mono_add_internal_call(
                "Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_SetTextureData2D",
                (const void *)fix22_fna3d_set_texture_data2d_icall
            );
            mono_add_internal_call(
                "Microsoft.Xna.Framework.Graphics.FNA3D_Impl::FNA3D_SetTextureData2D(System.IntPtr,System.IntPtr,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.IntPtr,System.Int32)",
                (const void *)fix22_fna3d_set_texture_data2d_icall
            );
            write_text(BINDINGFILE, "SETTEXTUREDATA2D_ICALL_REREGISTER=done\n");
            if (set_texture_data2d_method && opt_lookup_internal_call) {
                void *resolved = opt_lookup_internal_call(set_texture_data2d_method);
                char line[384];
                snprintf(line, sizeof(line),
                         "SETTEXTUREDATA2D_LOOKUP_AFTER_PATCH=%p expectedBridge=%p match=%u\n",
                         resolved, (void *)fix22_fna3d_set_texture_data2d_icall,
                         resolved == (void *)fix22_fna3d_set_texture_data2d_icall ? 1u : 0u);
                write_text(BINDINGFILE, line);
            }

            #define AUDIT_FNA3D_METHOD(method_name_literal, argc_value) do { \
                void *m = mono_class_get_method_from_name( \
                    fna3d_impl_class, method_name_literal, argc_value); \
                char line[768]; \
                if (!m) { \
                    snprintf(line, sizeof(line), \
                             "METHOD name=%s argc=%d status=NOT_FOUND\n", \
                             method_name_literal, argc_value); \
                    write_text(BINDINGFILE, line); \
                } else { \
                    unsigned int iflags = 0; \
                    unsigned int flags = opt_method_get_flags ? \
                        opt_method_get_flags(m, &iflags) : 0xffffffffu; \
                    unsigned int token = mono_method_get_token(m); \
                    void *icall = 0; \
                    if (opt_lookup_internal_call && (iflags & 0x1000u)) \
                        icall = opt_lookup_internal_call(m); \
                    snprintf(line, sizeof(line), \
                             "METHOD name=%s argc=%d token=0x%08x flags=0x%08x implFlags=0x%08x pinvoke=%u internalCall=%u runtimeCode=%u nativeCode=%u lookupIcall=%p\n", \
                             method_name_literal, argc_value, token, flags, iflags, \
                             (flags & 0x2000u) ? 1u : 0u, \
                             (iflags & 0x1000u) ? 1u : 0u, \
                             ((iflags & 0x0003u) == 0x0003u) ? 1u : 0u, \
                             ((iflags & 0x0003u) == 0x0001u) ? 1u : 0u, \
                             icall); \
                    write_text(BINDINGFILE, line); \
                } \
            } while (0)

            AUDIT_FNA3D_METHOD("FNA3D_GetDrawableSize", 3);
            AUDIT_FNA3D_METHOD("FNA3D_CreateDevice", 2);
            AUDIT_FNA3D_METHOD("FNA3D_GetMaxTextureSlots", 3);
            AUDIT_FNA3D_METHOD("FNA3D_GetMaxMultiSampleCount", 3);
            AUDIT_FNA3D_METHOD("FNA3D_CreateTexture2D", 6);
            AUDIT_FNA3D_METHOD("FNA3D_SetTextureData2D", 9);
            AUDIT_FNA3D_METHOD("FNA3D_GetTextureData2D", 9);
            AUDIT_FNA3D_METHOD("FNA3D_AddDisposeTexture", 2);
            AUDIT_FNA3D_METHOD("FNA3D_CreateTexture3D", 6);
            AUDIT_FNA3D_METHOD("FNA3D_CreateTextureCube", 5);
            AUDIT_FNA3D_METHOD("FNA3D_SetTextureData3D", 11);
            AUDIT_FNA3D_METHOD("FNA3D_SetTextureDataCube", 10);
            AUDIT_FNA3D_METHOD("FNA3D_SetViewport", 2);
            AUDIT_FNA3D_METHOD("FNA3D_SetScissorRect", 2);
            #undef AUDIT_FNA3D_METHOD

            if (!opt_method_get_flags)
                write_text(BINDINGFILE, "MONO_METHOD_GET_FLAGS=UNAVAILABLE\n");
            if (!opt_lookup_internal_call)
                write_text(BINDINGFILE, "MONO_LOOKUP_INTERNAL_CALL=UNAVAILABLE\n");
        }
    } else {
        write_text(BINDINGFILE, "FNA_IMAGE=UNAVAILABLE\n");
    }

    if (mono_install_assembly_preload_hook && g_assembly_name_get_name) {
        mono_install_assembly_preload_hook(assembly_preload_probe, 0);
    }
    checkpoint("assembly-preload-probe-installed");

    void *tml_asm = 0;
    void *tml_img = 0;
    if (file_exists(TML)) {
        checkpoint("before-optional-tmodloader-load");
        tml_asm = mono_domain_assembly_open(domain, TML);
        if (!tml_asm) checkpoint("optional-tmodloader-load-failed");
        else {
            tml_img = mono_assembly_get_image(tml_asm);
            if (!tml_img) return fail("tmodloader-image", "tModLoader image nula.", 88);
            checkpoint("optional-tmodloader-load-ok");
        }
    }
    if (!tml_img) return fail("tmodloader-load", "tModLoader.dll nao carregou para preparar Program.SavePath.", 89);
    if (mono_class_get_nested_types && g_class_get_method_from_name) {
        void *npcid_outer_for_trace = mono_class_from_name(tml_img, "Terraria.ID", "NPCID");
        if (npcid_outer_for_trace) {
            void *trace_iter = 0;
            void *trace_nested = 0;
            while ((trace_nested = mono_class_get_nested_types(npcid_outer_for_trace, &trace_iter)) != 0) {
                const char *trace_name = g_class_name ? g_class_name(trace_nested) : 0;
                if (trace_name && !strcmp(trace_name, "Sets")) {
                    g_npcid_sets_class = trace_nested;
                    g_npcid_sets_cctor_method = g_class_get_method_from_name(trace_nested, ".cctor", 0);
                    g_npcid_draw_offset_creation_method = g_class_get_method_from_name(trace_nested, "NPCBestiaryDrawOffsetCreation", 0);
                    g_npcid_get_redigit_entries_method = g_class_get_method_from_name(trace_nested, "GetRedigitEntries", 0);
                    g_npcid_get_leinfors_entries_method = g_class_get_method_from_name(trace_nested, "GetLeinforsEntries", 0);
                    g_npcid_get_grox_entries_method = g_class_get_method_from_name(trace_nested, "GetGroxEntries", 0);
                    break;
                }
            }
        }
    }
    write_text(LOGFILE, g_npcid_sets_cctor_method ? "NPCID_SETS_CCTOR_RESOLVE=OK\n" : "NPCID_SETS_CCTOR_RESOLVE=NOT_FOUND\n");
    if (g_npcid_draw_offset_creation_method) {
        char draw_probe[256];
        unsigned int draw_token = g_method_get_token ? g_method_get_token(g_npcid_draw_offset_creation_method) : 0;
        snprintf(draw_probe, sizeof(draw_probe), "NPCID_BESTIARY_DRAW_OFFSET_CREATION_RESOLVE=OK token=0x%08x\n", draw_token);
        write_text(LOGFILE, draw_probe);
    } else {
        write_text(LOGFILE, "NPCID_BESTIARY_DRAW_OFFSET_CREATION_RESOLVE=NOT_FOUND\n");
    }
    {
        char helper_probe[768];
        unsigned int rt = (g_npcid_get_redigit_entries_method && g_method_get_token) ? g_method_get_token(g_npcid_get_redigit_entries_method) : 0;
        unsigned int lt = (g_npcid_get_leinfors_entries_method && g_method_get_token) ? g_method_get_token(g_npcid_get_leinfors_entries_method) : 0;
        unsigned int gt = (g_npcid_get_grox_entries_method && g_method_get_token) ? g_method_get_token(g_npcid_get_grox_entries_method) : 0;
        snprintf(helper_probe, sizeof(helper_probe),
                 "NPCID_BESTIARY_HELPERS_RESOLVE redigit=%s token=0x%08x leinfors=%s token=0x%08x grox=%s token=0x%08x\n",
                 g_npcid_get_redigit_entries_method ? "OK" : "NOT_FOUND", rt,
                 g_npcid_get_leinfors_entries_method ? "OK" : "NOT_FOUND", lt,
                 g_npcid_get_grox_entries_method ? "OK" : "NOT_FOUND", gt);
        write_text(LOGFILE, helper_probe);
    }

    checkpoint("before-real-tml-startup-bootstrap");
    mkdir(SAVE_PARENT, 0770);
    mkdir(SAVE_PATH, 0770);

    void *program_class = mono_class_from_name(tml_img, "Terraria", "Program");
    if (!program_class) return fail("program-class-resolve", "Terraria.Program nao foi encontrado.", 90);
    if (!mono_class_init(program_class)) return fail("program-class-init", "mono_class_init(Terraria.Program) retornou false.", 91);

    void *program_vtable = mono_class_vtable ? mono_class_vtable(domain, program_class) : 0;
    if (!program_vtable) return fail("program-vtable", "vtable de Terraria.Program nao foi criada.", 92);

    void *save_field = mono_class_get_field_from_name(program_class, "SavePath");
    if (!save_field) return fail("program-savepath-field", "Terraria.Program.SavePath nao foi encontrado.", 93);

    void *save_parent_value = mono_string_new(domain, SAVE_PARENT);
    if (!save_parent_value) return fail("program-savepath-parent-string", "nao foi possivel criar string gerenciada para SavePath inicial.", 94);
    mono_field_static_set_value(program_vtable, save_field, save_parent_value); /* Reference field: direct object. */
    checkpoint("program-prestartup-savepath-seeded");

    #define RUN_STARTUP_STEP(TAG, METHOD, ARGS) do { \
        void *step_exc = 0; \
        checkpoint("before-" TAG); \
        mono_runtime_invoke((METHOD), 0, (ARGS), &step_exc); \
        checkpoint("after-" TAG); \
        if (step_exc) { \
            void *step_exc_class = mono_object_get_class(step_exc); \
            const char *step_exc_ns = step_exc_class ? mono_class_get_namespace(step_exc_class) : 0; \
            const char *step_exc_name = step_exc_class ? mono_class_get_name(step_exc_class) : 0; \
            snprintf(report, sizeof(report), \
                "MonoVM bootstrap corrigido - Startup Diagnostic\n\n" \
                "Startup step: %s\n" \
                "Result: MANAGED EXCEPTION\n" \
                "Exception type: %s.%s\n" \
                "Program.SavePath seed: %s\n" \
                "Working directory: %s\n" \
                "Assembly preload requests: %s\n" \
                "Preload hook calls: %d\n\n" \
                "Runtime: 8.0.23\nRID: android-arm64\n", \
                TAG, step_exc_ns ? step_exc_ns : "", step_exc_name ? step_exc_name : "<unknown>", \
                SAVE_PARENT, WORK_DIR, requested_assemblies[0] ? requested_assemblies : "<none>", preload_calls); \
            write_text(LOGFILE, report); \
            SDL_ShowSimpleMessageBox(0x40, "tML Android MonoVM - Phase 2.22.87", report, 0); \
            return 140; \
        } \
    } while (0)

    checkpoint("before-cfa-class-resolve");
    void *cfa_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "ControlledFolderAccessSupport");
    if (!cfa_class) return fail("cfa-class-resolve", "ControlledFolderAccessSupport nao foi encontrado.", 95);
    checkpoint("cfa-class-resolved");
    void *cfa_method = mono_class_get_method_from_name(cfa_class, "CheckFileSystemAccess", 0);
    if (!cfa_method) return fail("cfa-method-resolve", "CheckFileSystemAccess nao foi encontrado.", 96);
    RUN_STARTUP_STEP("controlled-folder-access-check", cfa_method, 0);

    checkpoint("working-directory-logdir-prepared");
    checkpoint("before-logging-class-resolve");
    void *logging_class = mono_class_from_name(tml_img, "Terraria.ModLoader", "Logging");
    if (!logging_class) return fail("logging-class-resolve", "Terraria.ModLoader.Logging nao foi encontrado.", 97);
    checkpoint("logging-class-resolved");

    checkpoint("before-logging-class-init");
    if (!mono_class_init(logging_class)) return fail("logging-class-init", "mono_class_init(Terraria.ModLoader.Logging) retornou false.", 98);
    checkpoint("after-logging-class-init");

    void *legacy_cleanups = mono_class_get_method_from_name(logging_class, "LegacyCleanups", 0);
    if (!legacy_cleanups) return fail("legacy-cleanups-resolve", "Logging.LegacyCleanups() nao foi encontrado.", 99);
    RUN_STARTUP_STEP("logging-legacy-cleanups", legacy_cleanups, 0);

    checkpoint("before-utils-class-resolve");
    void *utils_class = mono_class_from_name(tml_img, "Terraria", "Utils");
    if (!utils_class) return fail("utils-class-resolve", "Terraria.Utils nao foi encontrado.", 100);
    checkpoint("utils-class-resolved");
    void *try_create_dir = mono_class_get_method_from_name(utils_class, "TryCreatingDirectory", 1);
    if (!try_create_dir) return fail("try-create-dir-resolve", "Utils.TryCreatingDirectory(string) nao foi encontrado.", 101);
    void *log_dir_string = mono_string_new(domain, "tModLoader-Logs");
    if (!log_dir_string) return fail("log-dir-string", "nao foi possivel criar string para LogDir.", 102);
    void *try_create_dir_args[1];
    try_create_dir_args[0] = log_dir_string; /* Mono reference argument: object, not address of object. */
    RUN_STARTUP_STEP("logging-create-logdir", try_create_dir, try_create_dir_args);

    int log_file_client = 0;
    void *log_file_args[1];
    log_file_args[0] = &log_file_client;

    void *init_log_paths = mono_class_get_method_from_name(logging_class, "InitLogPaths", 1);
    if (!init_log_paths) return fail("init-log-paths-resolve", "Logging.InitLogPaths(LogFile) nao foi encontrado.", 103);
    RUN_STARTUP_STEP("logging-init-log-paths", init_log_paths, log_file_args);

    void *configure_appenders = mono_class_get_method_from_name(logging_class, "ConfigureAppenders", 1);
    if (!configure_appenders) return fail("configure-appenders-resolve", "Logging.ConfigureAppenders(LogFile) nao foi encontrado.", 104);
    int log_file_no_console = 1;
    void *log_file_no_console_args[1];
    log_file_no_console_args[0] = &log_file_no_console;
    checkpoint("before-configure-appenders-no-console");
    RUN_STARTUP_STEP("logging-configure-appenders-no-console", configure_appenders, log_file_no_console_args);
    checkpoint("after-configure-appenders-no-console");

    checkpoint("before-debug-appender-removal");
    if (!mono_assembly_get_object || !mono_method_desc_new || !mono_method_desc_search_in_class)
        return fail("debug-appender-removal-api", "APIs MonoMethodDesc/Assembly object indisponiveis.", 118);

    void *log4net_isolation_asm = mono_domain_assembly_open(domain, LOG4NET);
    if (!log4net_isolation_asm) return fail("log4net-isolation-open", "log4net.dll nao abriu para remover DebugAppender.", 119);
    void *log4net_isolation_img = mono_assembly_get_image(log4net_isolation_asm);
    if (!log4net_isolation_img) return fail("log4net-isolation-image", "log4net image nula no isolamento de appender.", 120);
    void *logmanager_isolation_class = mono_class_from_name(log4net_isolation_img, "log4net", "LogManager");
    if (!logmanager_isolation_class) return fail("logmanager-isolation-class", "log4net.LogManager nao resolvido no isolamento de appender.", 121);

    void *get_repository_method = 0;
    const char *repo_descs[] = {
        "log4net.LogManager:GetRepository(System.Reflection.Assembly)",
        ":GetRepository(System.Reflection.Assembly)"
    };
    for (int ri = 0; ri < 2 && !get_repository_method; ri++) {
        void *desc = mono_method_desc_new(repo_descs[ri], 1);
        if (desc) {
            get_repository_method = mono_method_desc_search_in_class(desc, logmanager_isolation_class);
            if (mono_method_desc_free) mono_method_desc_free(desc);
        }
    }
    if (!get_repository_method) return fail("get-repository-resolve", "LogManager.GetRepository(Assembly) nao resolvido.", 122);

    void *managed_tml_for_repo = mono_assembly_get_object(domain, tml_asm);
    if (!managed_tml_for_repo) return fail("managed-tml-repo", "Assembly gerenciada do tModLoader nao obtida para LogManager.GetRepository.", 123);
    void *repo_args[1];
    repo_args[0] = managed_tml_for_repo;
    void *repo_exc = 0;
    void *repo_object = mono_runtime_invoke(get_repository_method, 0, repo_args, &repo_exc);
    if (repo_exc) return fail("get-repository-invoke", "LogManager.GetRepository(Assembly) lancou excecao gerenciada.", 124);
    if (!repo_object) return fail("get-repository-null", "LogManager.GetRepository(Assembly) retornou null.", 125);
    checkpoint("log4net-repository-ready");

    void *repo_class = mono_object_get_class(repo_object);
    void *get_root_method = repo_class ? mono_class_get_method_from_name(repo_class, "get_Root", 0) : 0;
    if (!get_root_method) return fail("get-root-resolve", "Hierarchy.get_Root() nao resolvido.", 126);
    void *root_exc = 0;
    void *root_object = mono_runtime_invoke(get_root_method, repo_object, 0, &root_exc);
    if (root_exc) return fail("get-root-invoke", "Hierarchy.get_Root() lancou excecao gerenciada.", 127);
    if (!root_object) return fail("get-root-null", "Hierarchy.Root retornou null.", 128);
    checkpoint("log4net-root-ready");

    void *root_class = mono_object_get_class(root_object);
    if (!root_class) return fail("root-class", "Classe concreta de Hierarchy.Root nao resolvida.", 129);
    checkpoint("root-runtime-class-ready");

    void *logger_base_class = mono_class_from_name(log4net_isolation_img, "log4net.Repository.Hierarchy", "Logger");
    if (!logger_base_class) return fail("logger-base-class", "log4net.Repository.Hierarchy.Logger nao resolvida.", 130);
    checkpoint("logger-base-class-ready");

    /* Retain file logging. Only the desktop DebugAppender is incompatible. */
    void *remove_desc = mono_method_desc_new(":RemoveAppender(string)", 1);
    void *remove_debug = remove_desc ? mono_method_desc_search_in_class(remove_desc, logger_base_class) : 0;
    if (remove_desc && mono_method_desc_free) mono_method_desc_free(remove_desc);
    if (!remove_debug) return fail("remove-debug-appender-resolve", "Logger.RemoveAppender(string) nao resolvido.", 131);
    void *debug_name = mono_string_new(domain, "DebugAppender");
    if (!debug_name) return fail("debug-appender-name", "falha ao criar nome do appender.", 132);
    void *remove_debug_args[1] = { debug_name };
    void *remove_debug_exc = 0;
    checkpoint("before-remove-debug-appender");
    mono_runtime_invoke(remove_debug, root_object, remove_debug_args, &remove_debug_exc);
    if (remove_debug_exc) return fail("remove-debug-appender", "RemoveAppender lancou excecao; file logger nao validado.", 133);
    checkpoint("file-appender-retained-debug-appender-removed");

    if (!mono_class_vtable || !mono_field_static_get_value) return fail("logging-field-api", "APIs para ler Logging.LogPath nao estao disponiveis.", 105);
    void *logging_vtable = mono_class_vtable(domain, logging_class);
    if (!logging_vtable) return fail("logging-vtable", "vtable de Terraria.ModLoader.Logging nao foi criada.", 106);
    void *log_path_field = mono_class_get_field_from_name(logging_class, "<LogPath>k__BackingField");
    if (!log_path_field) return fail("logging-logpath-field", "backing field de Logging.LogPath nao foi encontrado.", 107);
    void *log_path_value = 0;
    mono_field_static_get_value(logging_vtable, log_path_field, &log_path_value);
    if (!log_path_value) return fail("logging-logpath-null", "Logging.LogPath ficou nulo apos InitLogPaths.", 108);
    checkpoint("logging-logpath-ready");
    if (g_string_utf8) {
        char *managed_log_path_utf8 = g_string_utf8(log_path_value);
        if (managed_log_path_utf8) {
            char log_path_line[1800];
            char log_abs[1800];
            snprintf(log_abs, sizeof(log_abs), "%s/%s", WORK_DIR, managed_log_path_utf8);
            snprintf(log_path_line, sizeof(log_path_line),
                     "TML_LOG_PATH managed=%s absolute=%s exists_before_probe=%s\n",
                     managed_log_path_utf8, log_abs, file_exists(log_abs) ? "YES" : "NO");
            write_text(LOGFILE, log_path_line);
            if (g_mono_free) g_mono_free(managed_log_path_utf8);
        }
    }

    void *try_update_creation = mono_class_get_method_from_name(logging_class, "TryUpdatingFileCreationDate", 1);
    if (!try_update_creation) return fail("try-update-creation-resolve", "Logging.TryUpdatingFileCreationDate(string) nao foi encontrado.", 109);
    void *try_update_args[1];
    try_update_args[0] = log_path_value; /* Mono reference argument: object, not address of object. */
    RUN_STARTUP_STEP("logging-update-file-creation-date", try_update_creation, try_update_args);

    checkpoint("logging-init-manual-ok");

    checkpoint("before-buildinfo-class-resolve");
    void *buildinfo_class = mono_class_from_name(tml_img, "Terraria.ModLoader", "BuildInfo");
    if (!buildinfo_class) return fail("buildinfo-class-resolve", "Terraria.ModLoader.BuildInfo nao foi encontrado.", 110);
    checkpoint("before-buildinfo-class-init");
    if (!mono_class_init(buildinfo_class)) return fail("buildinfo-class-init", "mono_class_init(Terraria.ModLoader.BuildInfo) retornou false.", 111);
    checkpoint("after-buildinfo-class-init");

    checkpoint("before-tml-logger-read");
    void *tml_logger_field = mono_class_get_field_from_name(logging_class, "<tML>k__BackingField");
    if (!tml_logger_field) return fail("tml-logger-field", "backing field de Logging.tML nao foi encontrado.", 112);
    void *tml_logger = 0;
    mono_field_static_get_value(logging_vtable, tml_logger_field, &tml_logger);
    if (!tml_logger) return fail("tml-logger-null", "Logging.tML esta nulo apos Logging.Init manual.", 113);
    checkpoint("tml-logger-ready");

    void *logger_class = mono_object_get_class(tml_logger);
    if (!logger_class) return fail("tml-logger-class", "classe concreta do logger tML nao foi obtida.", 114);
    void *logger_info = mono_class_get_method_from_name(logger_class, "Info", 1);
    if (!logger_info) return fail("tml-logger-info-resolve", "metodo Info(object) do logger concreto nao foi encontrado.", 115);
    void *probe_log_string = mono_string_new(domain, "Phase 2.22.86 file-appender tML logger write probe");
    if (!probe_log_string) return fail("tml-logger-probe-string", "nao foi possivel criar string do probe de log.", 116);
    void *probe_log_args[1];
    probe_log_args[0] = probe_log_string; /* Mono reference argument: object, not address of object. */
    checkpoint("before-first-tml-logger-write");
    void *probe_log_exc = 0;
    mono_runtime_invoke(logger_info, tml_logger, probe_log_args, &probe_log_exc);
    checkpoint("after-first-tml-logger-write");
    if (probe_log_exc) {
        void *probe_exc_class = mono_object_get_class(probe_log_exc);
        const char *probe_exc_ns = probe_exc_class ? mono_class_get_namespace(probe_exc_class) : 0;
        const char *probe_exc_name = probe_exc_class ? mono_class_get_name(probe_exc_class) : 0;
        snprintf(report, sizeof(report),
            "MonoVM Phase 2.22.86 - LogArchiver Archive Bypass Diagnostic\n\n"
            "First tML logger write: MANAGED EXCEPTION\n"
            "Exception type: %s.%s\n"
            "Working directory: %s\n"
            "Assembly preload requests: %s\n"
            "Preload hook calls: %d\n\n"
            "Runtime: 8.0.23\nRID: android-arm64\n",
            probe_exc_ns ? probe_exc_ns : "", probe_exc_name ? probe_exc_name : "<unknown>",
            WORK_DIR, requested_assemblies[0] ? requested_assemblies : "<none>", preload_calls);
        write_text(LOGFILE, report);
        SDL_ShowSimpleMessageBox(0x40, "tML Android MonoVM - Phase 2.22.87", report, 0);
        return 143;
    }
    checkpoint("first-tml-logger-write-file-appender-ok");
    {
        char client_log_abs[1800];
        snprintf(client_log_abs, sizeof(client_log_abs), "%s/tModLoader-Logs/client.log", WORK_DIR);
        write_text(LOGFILE, file_exists(client_log_abs) ?
                   "TML_LOG_FILE_AFTER_PROBE=YES path=work/tModLoader-Logs/client.log\n" :
                   "TML_LOG_FILE_AFTER_PROBE=NO path=work/tModLoader-Logs/client.log\n");
    }
    checkpoint("file-appender-first-write-confirmed");

    checkpoint("logging-logstartup-preamble-bypassed");

    /* This is diagnostics, not required mod functionality. FirstChanceExceptionHandler
       builds managed stack traces for exceptions that may be caught normally.
       Keep native invocation diagnostics without installing this global handler. */
    checkpoint("managed-first-chance-stacktrace-handler-disabled-android");

    checkpoint("before-assembly-resolving-class-resolve");
    void *assembly_resolving_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Core", "AssemblyResolving");
    if (!assembly_resolving_class) return fail("assembly-resolving-class", "Terraria.ModLoader.Core.AssemblyResolving nao foi encontrado.", 118);
    void *assembly_resolving_init = mono_class_get_method_from_name(assembly_resolving_class, "Init", 0);
    if (!assembly_resolving_init) return fail("assembly-resolving-init-resolve", "AssemblyResolving.Init() nao foi encontrado.", 119);
    RUN_STARTUP_STEP("assembly-resolving-init", assembly_resolving_init, 0);

    checkpoint("before-logging-hooks-class-resolve");
    void *logging_hooks_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "LoggingHooks");
    if (!logging_hooks_class) return fail("logging-hooks-class", "Terraria.ModLoader.Engine.LoggingHooks nao foi encontrado.", 120);
    checkpoint("before-logging-hooks-class-init");
    if (!mono_class_init(logging_hooks_class)) return fail("logging-hooks-class-init", "mono_class_init(LoggingHooks) retornou false.", 121);
    checkpoint("after-logging-hooks-class-init");

    void *fix_console_pipe = mono_class_get_method_from_name(logging_hooks_class, "FixBrokenConsolePipeError", 0);
    if (!fix_console_pipe) return fail("logging-hooks-fix-console-resolve", "LoggingHooks.FixBrokenConsolePipeError() nao foi encontrado.", 122);
    RUN_STARTUP_STEP("logging-hooks-fix-console-pipe", fix_console_pipe, 0);

    void *prettify_stack = mono_class_get_method_from_name(logging_hooks_class, "PrettifyStackTraceSources", 0);
    if (!prettify_stack) return fail("logging-hooks-prettify-resolve", "LoggingHooks.PrettifyStackTraceSources() nao foi encontrado.", 123);
    checkpoint("logging-hooks-prettify-resolved");
    checkpoint("logging-hooks-prettify-stacktrace-sources-skipped");

    void *hook_web_requests = mono_class_get_method_from_name(logging_hooks_class, "HookWebRequests", 0);
    if (!hook_web_requests) return fail("logging-hooks-web-resolve", "LoggingHooks.HookWebRequests() nao foi encontrado.", 124);
    checkpoint("logging-hooks-hook-web-requests-resolved");
    checkpoint("logging-hooks-hook-web-requests-skipped");

    void *hook_process_start = mono_class_get_method_from_name(logging_hooks_class, "HookProcessStart", 0);
    if (!hook_process_start) return fail("logging-hooks-process-resolve", "LoggingHooks.HookProcessStart() nao foi encontrado.", 125);
    checkpoint("logging-hooks-hook-process-start-resolved");
    checkpoint("logging-hooks-hook-process-start-skipped");
    checkpoint("logging-hooks-runtime-detour-hooks-skipped-android");
    checkpoint("logging-hooks-stepwise-ok");

    checkpoint("before-log-archiver-class-resolve");
    void *log_archiver_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "LogArchiver");
    if (!log_archiver_class) return fail("log-archiver-class", "Terraria.ModLoader.Engine.LogArchiver nao foi encontrado.", 126);
    checkpoint("log-archiver-class-resolved");

    checkpoint("before-log-archiver-class-init");
    if (!mono_class_init(log_archiver_class)) return fail("log-archiver-class-init", "mono_class_init(LogArchiver) retornou false.", 127);
    checkpoint("after-log-archiver-class-init");

    void *setup_log_dirs = mono_class_get_method_from_name(log_archiver_class, "SetupLogDirs", 0);
    if (!setup_log_dirs) return fail("log-archiver-setup-log-dirs-resolve", "LogArchiver.SetupLogDirs() nao foi encontrado.", 128);
    RUN_STARTUP_STEP("log-archiver-setup-log-dirs", setup_log_dirs, 0);

    void *move_zips = mono_class_get_method_from_name(log_archiver_class, "MoveZipsToArchiveDir", 0);
    if (!move_zips) return fail("log-archiver-move-zips-resolve", "LogArchiver.MoveZipsToArchiveDir() nao foi encontrado.", 129);
    RUN_STARTUP_STEP("log-archiver-move-zips", move_zips, 0);

    void *archive_old_logs = mono_class_get_method_from_name(log_archiver_class, "Archive", 0);
    if (!archive_old_logs) return fail("log-archiver-archive-resolve", "LogArchiver.Archive() nao foi encontrado.", 130);
    checkpoint("log-archiver-archive-resolved");
    checkpoint("log-archiver-archive-skipped-android");

    void *delete_old_archives = mono_class_get_method_from_name(log_archiver_class, "DeleteOldArchives", 0);
    if (!delete_old_archives) return fail("log-archiver-delete-old-archives-resolve", "LogArchiver.DeleteOldArchives() nao foi encontrado.", 131);
    RUN_STARTUP_STEP("log-archiver-delete-old-archives", delete_old_archives, 0);
    checkpoint("log-archiver-stepwise-ok");

    checkpoint("before-native-exception-handling-class-resolve");
    void *native_exception_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "NativeExceptionHandling");
    if (!native_exception_class) return fail("native-exception-class", "Terraria.ModLoader.Engine.NativeExceptionHandling nao foi encontrado.", 124);
    void *native_exception_init = mono_class_get_method_from_name(native_exception_class, "Init", 0);
    if (!native_exception_init) return fail("native-exception-init-resolve", "NativeExceptionHandling.Init() nao foi encontrado.", 125);
    RUN_STARTUP_STEP("native-exception-handling-init", native_exception_init, 0);

    checkpoint("logging-logstartup-core-init-ok");

    void *set_save_path = mono_class_get_method_from_name(program_class, "SetSavePath", 0);
    if (!set_save_path) return fail("set-savepath-resolve", "Terraria.Program.SetSavePath() nao foi encontrado.", 100);
    RUN_STARTUP_STEP("program-set-savepath", set_save_path, 0);

    void *save_after_set = 0;
    mono_field_static_get_value(program_vtable, save_field, &save_after_set);
    if (!save_after_set) return fail("program-savepath-after-set", "Program.SavePath ficou nulo apos SetSavePath.", 101);
    checkpoint("program-savepath-after-set-ok");

    /* The desktop DPI helper unconditionally calls SDL_VideoInit. On Android,
       SDLActivity/FNA must own the video lifecycle; configure the high-DPI policy
       without initializing or resetting video from this diagnostic helper. */
    checkpoint("before-android-highdpi-policy");
    if (!configure_android_highdpi())
        return fail("android-highdpi-policy", "nao foi possivel configurar FNA_GRAPHICS_ENABLE_HIGHDPI.", 145);
    checkpoint("android-highdpi-policy-ready-video-init-delegated");

    checkpoint("before-native-libraries-class-resolve");
    void *native_libraries_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "NativeLibraries");
    if (!native_libraries_class) return fail("native-libraries-class-resolve", "Terraria.ModLoader.Engine.NativeLibraries nao foi encontrado.", 103);
    checkpoint("native-libraries-class-resolved");
    void *faudio_check = mono_class_get_method_from_name(native_libraries_class, "CheckNativeFAudioDependencies", 0);
    if (!faudio_check) return fail("faudio-check-resolve", "CheckNativeFAudioDependencies nao foi encontrado.", 104);
    RUN_STARTUP_STEP("check-native-faudio-dependencies", faudio_check, 0);

    checkpoint("before-fna-logging-class-resolve");
    void *fna_logging_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "FNALogging");
    if (!fna_logging_class) return fail("fna-logging-class-resolve", "Terraria.ModLoader.Engine.FNALogging nao foi encontrado.", 105);
    checkpoint("fna-logging-class-resolved");
    void *redirect_logs = mono_class_get_method_from_name(fna_logging_class, "RedirectLogs", 0);
    if (!redirect_logs) return fail("fna-redirect-resolve", "FNALogging.RedirectLogs nao foi encontrado.", 106);
    checkpoint("fna-logging-redirect-resolved");
    write_text(LOGFILE, "FNA_LOGGING_POLICY=RedirectLogs skipped on Android: method only installs diagnostic log delegates and queries SDL/FNA3D/FAudio versions; SDL_GetVersion(out struct) crashes in Mono before native entry.\n");
    checkpoint("fna-logging-redirect-skipped-android");


    #undef RUN_STARTUP_STEP
    checkpoint("startup-sequence-tml-stepwise-ok");

    void *save_check = 0;
    mono_field_static_get_value(program_vtable, save_field, &save_check);
    if (!save_check) return fail("program-savepath-after-startup", "Program.SavePath ficou nulo apos startup passo-a-passo.", 96);

    void *main_class_startup = mono_class_from_name(tml_img, "Terraria", "Main");
    if (!main_class_startup) return fail("main-class-resolve-after-startup", "Terraria.Main nao foi resolvido apos startup.", 97);
    g_domain_diag = domain;
    g_main_class_diag = main_class_startup;
    g_player_class_diag = mono_class_from_name(tml_img, "Terraria", "Player");
    checkpoint("before-main-class-init-after-startup");
    if (!mono_class_init(main_class_startup)) return fail("main-class-init-after-startup", "mono_class_init(Terraria.Main) retornou false apos startup passo-a-passo.", 98);
    checkpoint("main-class-init-after-startup-ok");

    /* Desktop install verification expects Steam/GOG and Terraria.exe. The Android
       port owns its application/container validation, so preserve the real RunGame
       order but bypass only this desktop distribution verifier. */
    checkpoint("before-install-verifier-startup-policy");
    write_text(LOGFILE, "ANDROID_POLICY=InstallVerifier.Startup skipped: desktop Steam/GOG/Terraria.exe validation is not applicable to the Android container.\n");
    checkpoint("install-verifier-startup-skipped-android");

    #define RUN_ENGINE_STEP(TAG, METHOD) do { \
        void *engine_exc = 0; \
        checkpoint("before-" TAG); \
        mono_runtime_invoke((METHOD), 0, 0, &engine_exc); \
        checkpoint("after-" TAG); \
        if (engine_exc) { \
            void *engine_exc_class = mono_object_get_class(engine_exc); \
            const char *engine_exc_ns = engine_exc_class ? mono_class_get_namespace(engine_exc_class) : 0; \
            const char *engine_exc_name = engine_exc_class ? mono_class_get_name(engine_exc_class) : 0; \
            char engine_detail[4096]; \
            exception_summary(engine_exc, engine_detail, sizeof(engine_detail)); \
            snprintf(report, sizeof(report), \
                "MonoVM Phase 2.22.86 - EngineInit Stepwise Diagnostic\n\n" \
                "Engine step: %s\n" \
                "Result: MANAGED EXCEPTION\n" \
                "Exception type: %s.%s\n" \
                "Exception.ToString(): %s\n" \
                "Assembly preload requests: %s\n" \
                "Preload hook calls: %d\n\n" \
                "Runtime: 8.0.23\nRID: android-arm64\n", \
                TAG, engine_exc_ns ? engine_exc_ns : "", engine_exc_name ? engine_exc_name : "<unknown>", \
                engine_detail[0] ? engine_detail : "<sem detalhe>", \
                requested_assemblies[0] ? requested_assemblies : "<none>", preload_calls); \
            write_text(LOGFILE, report); \
            SDL_ShowSimpleMessageBox(0x40, "tML Android MonoVM - Phase 2.22.87", report, 0); \
            return 146; \
        } \
    } while (0)

    checkpoint("before-engine-file-association-class-resolve");
    void *file_assoc_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "FileAssociationSupport");
    if (!file_assoc_class) return fail("engine-file-association-class", "FileAssociationSupport nao foi encontrado.", 147);
    void *file_assoc_update = mono_class_get_method_from_name(file_assoc_class, "UpdateFileAssociation", 0);
    if (!file_assoc_update) return fail("engine-file-association-method", "UpdateFileAssociation() nao foi encontrado.", 148);
    RUN_ENGINE_STEP("engine-file-association", file_assoc_update);

    checkpoint("before-engine-folder-shortcut-class-resolve");
    void *folder_shortcut_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "FolderShortcutSupport");
    if (!folder_shortcut_class) return fail("engine-folder-shortcut-class", "FolderShortcutSupport nao foi encontrado.", 149);
    void *folder_shortcut_update = mono_class_get_method_from_name(folder_shortcut_class, "UpdateFolderShortcuts", 0);
    if (!folder_shortcut_update) return fail("engine-folder-shortcut-method", "UpdateFolderShortcuts() nao foi encontrado.", 150);
    RUN_ENGINE_STEP("engine-folder-shortcuts", folder_shortcut_update);

    checkpoint("before-engine-monomod-hooks-class-resolve");
    void *monomod_hooks_class = mono_class_from_name(tml_img, "Terraria.ModLoader", "MonoModHooks");
    if (!monomod_hooks_class) return fail("engine-monomod-hooks-class", "Terraria.ModLoader.MonoModHooks nao foi encontrado.", 151);
    void *monomod_hooks_init = mono_class_get_method_from_name(monomod_hooks_class, "Initialize", 0);
    if (!monomod_hooks_init) return fail("engine-monomod-hooks-method", "MonoModHooks.Initialize() nao foi encontrado.", 152);
    RUN_ENGINE_STEP("engine-monomod-hooks-init", monomod_hooks_init);

    checkpoint("before-engine-fna-fixes-class-resolve");
    void *fna_fixes_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "FNAFixes");
    if (!fna_fixes_class) return fail("engine-fna-fixes-class", "Terraria.ModLoader.Engine.FNAFixes nao foi encontrado.", 153);
    void *fna_fixes_init = mono_class_get_method_from_name(fna_fixes_class, "Init", 0);
    if (!fna_fixes_init) return fail("engine-fna-fixes-method", "FNAFixes.Init() nao foi encontrado.", 154);
    RUN_ENGINE_STEP("engine-fna-fixes-init", fna_fixes_init);

    checkpoint("before-engine-loader-manager-class-resolve");
    void *loader_manager_class = mono_class_from_name(tml_img, "Terraria.ModLoader", "LoaderManager");
    if (!loader_manager_class) return fail("engine-loader-manager-class", "Terraria.ModLoader.LoaderManager nao foi encontrado.", 155);
    void *loader_manager_autoload = mono_class_get_method_from_name(loader_manager_class, "AutoLoad", 0);
    if (!loader_manager_autoload) return fail("engine-loader-manager-autoload-method", "LoaderManager.AutoLoad() nao foi encontrado.", 156);
    RUN_ENGINE_STEP("engine-loader-manager-autoload", loader_manager_autoload);
    checkpoint("engine-init-stepwise-ok");

    #undef RUN_ENGINE_STEP

    checkpoint("before-main-engine-object-new");
    void *main_engine_object = mono_object_new(domain, main_class_startup);
    if (!main_engine_object) return fail("main-engine-object-new", "mono_object_new(Terraria.Main) retornou nulo.", 157);
    checkpoint("main-engine-object-allocated");

    void *main_engine_ctor = mono_class_get_method_from_name(main_class_startup, ".ctor", 0);
    if (!main_engine_ctor) return fail("main-engine-ctor-resolve", "Terraria.Main .ctor() nao foi encontrado.", 158);
    checkpoint("main-engine-ctor-resolved");

    checkpoint("before-main-engine-ctor-invoke");
    void *main_engine_ctor_exc = 0;
    mono_runtime_invoke(main_engine_ctor, main_engine_object, 0, &main_engine_ctor_exc);
    checkpoint("after-main-engine-ctor-invoke");
    if (main_engine_ctor_exc) {
        void *ctor_exc_class = mono_object_get_class(main_engine_ctor_exc);
        const char *ctor_exc_ns = ctor_exc_class ? mono_class_get_namespace(ctor_exc_class) : 0;
        const char *ctor_exc_name = ctor_exc_class ? mono_class_get_name(ctor_exc_class) : 0;
        char ctor_detail[4096];
        exception_summary(main_engine_ctor_exc, ctor_detail, sizeof(ctor_detail));
        snprintf(report, sizeof(report),
            "MonoVM Phase 2.22.86 - Terraria.Main Constructor Diagnostic\n\n"
            "EngineInit stepwise: OK\n"
            "Terraria.Main allocation: OK\n"
            "Terraria.Main .ctor(): MANAGED EXCEPTION\n"
            "Exception type: %s.%s\n"
            "Exception detail: %s\n"
            "Assembly preload requests: %s\n"
            "Preload hook calls: %d\n\n"
            "Runtime: 8.0.23\nRID: android-arm64\n",
            ctor_exc_ns ? ctor_exc_ns : "", ctor_exc_name ? ctor_exc_name : "<unknown>",
            ctor_detail[0] ? ctor_detail : "<sem detalhe>",
            requested_assemblies[0] ? requested_assemblies : "<none>", preload_calls);
        write_text(LOGFILE, report);
        SDL_ShowSimpleMessageBox(0x40, "tML Android MonoVM - Phase 2.22.87", report, 0);
        return 159;
    }
    checkpoint("main-engine-ctor-ok");

    int main_instance_set = 0;
    void *main_instance_field = mono_class_get_field_from_name(main_class_startup, "instance");
    void *main_vtable_diag = mono_class_vtable ? mono_class_vtable(domain, main_class_startup) : 0;
    if (main_instance_field && main_vtable_diag && mono_field_static_get_value) {
        void *main_instance_value = 0;
        mono_field_static_get_value(main_vtable_diag, main_instance_field, &main_instance_value);
        main_instance_set = main_instance_value != 0;
    }
    checkpoint("main-engine-instance-state-captured");

    /* Program.RunGame pre-Run sequence, kept in the original desktop order.
       Android has no supported Steam client/GameServer backend in this host.
       SocialAPI is therefore initialized to its real SocialMode.None state,
       while the rest of the pre-Run sequence remains unchanged. */
    checkpoint("before-prerun-lang-class-resolve");
    void *lang_class = mono_class_from_name(tml_img, "Terraria", "Lang");
    if (!lang_class) return fail("prerun-lang-class", "Terraria.Lang nao foi encontrado.", 160);
    void *lang_init_legacy = mono_class_get_method_from_name(lang_class, "InitializeLegacyLocalization", 0);
    if (!lang_init_legacy) return fail("prerun-lang-method", "Lang.InitializeLegacyLocalization() nao foi encontrado.", 161);
    checkpoint("before-prerun-lang-initialize");
    void *prerun_exc = 0;
    mono_runtime_invoke(lang_init_legacy, 0, 0, &prerun_exc);
    checkpoint("after-prerun-lang-initialize");
    if (prerun_exc) {
        char detail[4096];
        exception_summary(prerun_exc, detail, sizeof(detail));
        snprintf(report, sizeof(report),
            "MonoVM Phase 2.22.86 - Pre-Run Diagnostic\n\n"
            "EngineInit: OK\nTerraria.Main constructor: OK\n"
            "Pre-Run step: Lang.InitializeLegacyLocalization\n"
            "Result: MANAGED EXCEPTION\nException detail: %s\n"
            "Assembly preload requests: %s\nPreload hook calls: %d\n\n"
            "Runtime: 8.0.23\nRID: android-arm64\n",
            detail[0] ? detail : "<sem detalhe>",
            requested_assemblies[0] ? requested_assemblies : "<none>", preload_calls);
        write_text(LOGFILE, report);
        SDL_ShowSimpleMessageBox(0x40, "tML Android MonoVM - Phase 2.22.87", report, 0);
        return 162;
    }
    checkpoint("prerun-lang-ok");

    checkpoint("before-prerun-social-class-resolve");
    void *social_class = mono_class_from_name(tml_img, "Terraria.Social", "SocialAPI");
    if (!social_class) return fail("prerun-social-class", "Terraria.Social.SocialAPI nao foi encontrado.", 163);
    void *social_vtable = mono_class_vtable ? mono_class_vtable(domain, social_class) : 0;
    if (!social_vtable) return fail("prerun-social-vtable", "SocialAPI vtable nao pode ser criada.", 164);
    checkpoint("before-prerun-social-none-state");
    typedef void (*mono_runtime_class_init_t)(void *);
    mono_runtime_class_init_t mono_runtime_class_init = (mono_runtime_class_init_t)dlsym(mono, "mono_runtime_class_init");
    if (!mono_runtime_class_init) return fail("prerun-social-class-init-api", "mono_runtime_class_init nao esta disponivel.", 165);
    mono_runtime_class_init(social_vtable);
    void *social_mode_field = mono_class_get_field_from_name(social_class, "_mode");
    if (!social_mode_field) return fail("prerun-social-mode-field", "SocialAPI._mode nao foi encontrado.", 166);
    int social_mode_none = 0;
    mono_field_static_set_value(social_vtable, social_mode_field, &social_mode_none);
    int social_mode_verify = -1;
    mono_field_static_get_value(social_vtable, social_mode_field, &social_mode_verify);
    if (social_mode_verify != 0) return fail("prerun-social-mode-verify", "SocialAPI._mode nao permaneceu em SocialMode.None.", 167);
    write_text(LOGFILE, "ANDROID_POLICY=SocialAPI backend fixed to SocialMode.None; Steam/Workshop network backend is not initialized on Android. Local Mods directory remains active.\n");
    checkpoint("prerun-social-ok");

    checkpoint("before-prerun-launchinitializer-class-resolve");
    void *launch_initializer_class = mono_class_from_name(tml_img, "Terraria.Initializers", "LaunchInitializer");
    if (!launch_initializer_class) return fail("prerun-launchinitializer-class", "Terraria.Initializers.LaunchInitializer nao foi encontrado.", 168);
    void *launch_load_parameters = mono_class_get_method_from_name(launch_initializer_class, "LoadParameters", 1);
    if (!launch_load_parameters) return fail("prerun-launchinitializer-method", "LaunchInitializer.LoadParameters(Main) nao foi encontrado.", 169);
    void *launch_args[1] = { main_engine_object };
    checkpoint("before-prerun-launchinitializer-loadparameters");
    prerun_exc = 0;
    mono_runtime_invoke(launch_load_parameters, 0, launch_args, &prerun_exc);
    checkpoint("after-prerun-launchinitializer-loadparameters");
    if (prerun_exc) {
        char detail[4096];
        exception_summary(prerun_exc, detail, sizeof(detail));
        snprintf(report, sizeof(report),
            "MonoVM Phase 2.22.86 - Pre-Run Diagnostic\n\n"
            "EngineInit: OK\nTerraria.Main constructor: OK\nLegacy localization: OK\nSocialMode.None: OK\n"
            "LaunchInitializer.LoadParameters(Main): MANAGED EXCEPTION\nException detail: %s\n"
            "Assembly preload requests: %s\nPreload hook calls: %d\n",
            detail[0] ? detail : "<sem detalhe>",
            requested_assemblies[0] ? requested_assemblies : "<none>", preload_calls);
        write_text(LOGFILE, report);
        SDL_ShowSimpleMessageBox(0x40, "tML Android MonoVM - Phase 2.22.87", report, 0);
        return 170;
    }
    checkpoint("prerun-launchinitializer-ok");
    checkpoint("prerun-sequence-ok");

    checkpoint("before-install-verifier-runtime-class-resolve");
    void *install_verifier_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Engine", "InstallVerifier");
    if (!install_verifier_class) return fail("install-verifier-runtime-class", "InstallVerifier nao foi encontrado no runtime.", 171);

    checkpoint("before-install-verifier-runtime-vtable-create");
    void *install_verifier_vtable = mono_class_vtable ? mono_class_vtable(domain, install_verifier_class) : 0;
    checkpoint("after-install-verifier-runtime-vtable-create");
    if (!install_verifier_vtable) return fail("install-verifier-runtime-vtable", "InstallVerifier vtable nao pode ser criada.", 172);

    unsigned char *install_vt = (unsigned char *)install_verifier_vtable;
    void *layout_klass = *(void **)(install_vt + 0);
    void *layout_domain = *(void **)(install_vt + 16);
    unsigned int layout_rank = install_vt[52];
    unsigned int layout_initialized_before = install_vt[53];
    unsigned int layout_flags = install_vt[54];
    unsigned int layout_init_failed = install_vt[56] & 1U;
    char install_layout_line[512];
    snprintf(install_layout_line, sizeof(install_layout_line),
             "INSTALL_VERIFIER_VTABLE klass=%p expected_klass=%p domain=%p expected_domain=%p rank=%u initialized=%u flags=0x%02x init_failed=%u initialized_offset=53\n",
             layout_klass, install_verifier_class, layout_domain, domain,
             layout_rank, layout_initialized_before, layout_flags, layout_init_failed);
    write_text(LOGFILE, install_layout_line);
    if (layout_klass != install_verifier_class || layout_domain != domain)
        return fail("install-verifier-runtime-vtable-layout", "layout MonoVTable inesperado para .NET 8 android-arm64; bypass nao aplicado.", 173);
    if (layout_init_failed)
        return fail("install-verifier-runtime-init-failed", "InstallVerifier ja estava marcado como init_failed antes da politica Android.", 174);

    checkpoint("before-install-verifier-runtime-init-state-bridge");
    if (!layout_initialized_before)
        install_vt[53] = 1;
    if (install_vt[53] != 1)
        return fail("install-verifier-runtime-init-state", "nao foi possivel marcar InstallVerifier como inicializado no MonoVTable.", 175);
    write_text(LOGFILE, "ANDROID_RUNTIME_BRIDGE=InstallVerifier MonoVTable marked initialized without executing desktop-only .cctor; no tModLoader.dll bytes were modified.\n");
    checkpoint("install-verifier-runtime-init-state-bridge-ready");

    void *distribution_platform_field = mono_class_get_field_from_name(install_verifier_class, "DistributionPlatform");
    if (!distribution_platform_field) return fail("install-verifier-runtime-field", "InstallVerifier.DistributionPlatform nao foi encontrado.", 176);
    int distribution_platform = 0;
    mono_field_static_set_value(install_verifier_vtable, distribution_platform_field, &distribution_platform);
    distribution_platform = -1;
    mono_field_static_get_value(install_verifier_vtable, distribution_platform_field, &distribution_platform);
    if (distribution_platform != 0) return fail("install-verifier-runtime-policy", "DistributionPlatform deveria permanecer Unknown no host Android.", 177);
    write_text(LOGFILE, "ANDROID_POLICY=InstallVerifier desktop verifier remains unexecuted; DistributionPlatform=Unknown, Startup skipped, SocialMode.None active.\n");
    checkpoint("install-verifier-runtime-cctor-android-ok");

    checkpoint("before-android-content-route");
    if (!prepare_android_content_cwd()) return fail("android-content-route", "nao foi possivel selecionar o diretorio de trabalho para Content.", 175);
    checkpoint("android-content-route-ready");

    /* Keep the normal tModLoader discovery path deterministic on Android. */
    checkpoint("before-normal-modpath-bind");
    mkdir(MODS_DIR, 0770);
    void *mod_organizer_class = mono_class_from_name(tml_img, "Terraria.ModLoader.Core", "ModOrganizer");
    if (!mod_organizer_class) return fail("modorganizer-class", "ModOrganizer nao foi encontrado.", 195);
    void *mod_organizer_vtable = mono_class_vtable ? mono_class_vtable(domain, mod_organizer_class) : 0;
    if (!mod_organizer_vtable) return fail("modorganizer-vtable", "ModOrganizer vtable nao foi criada.", 196);
    mono_runtime_class_init(mod_organizer_vtable);
    void *mod_path_field = mono_class_get_field_from_name(mod_organizer_class, "modPath");
    if (!mod_path_field) return fail("modorganizer-modpath-field", "ModOrganizer.modPath nao foi encontrado.", 197);
    void *mods_dir_string = mono_string_new(domain, MODS_DIR);
    if (!mods_dir_string) return fail("modorganizer-modpath-string", "nao foi possivel criar string para Mods dir.", 198);
    mono_field_static_set_value(mod_organizer_vtable, mod_path_field, mods_dir_string);
    checkpoint("normal-modpath-bound");
    write_text(LOGFILE, "NORMAL_LOADER_INPUT=Split.tmod is installed in Main.SavePath/Mods and enabled through enabled.json; no direct TmodFile/AssemblyManager probe is invoked by BootstrapFix18.11.\n");

    void *mod_loader_class = mono_class_from_name(tml_img, "Terraria.ModLoader", "ModLoader");
    if (!mod_loader_class) return fail("modloader-class", "Terraria.ModLoader.ModLoader nao foi encontrado.", 199);
    void *mod_loader_vtable = mono_class_vtable ? mono_class_vtable(domain, mod_loader_class) : 0;
    if (!mod_loader_vtable) return fail("modloader-vtable", "ModLoader vtable nao foi criada.", 200);
    void *is_loading_field = mono_class_get_field_from_name(mod_loader_class, "isLoading");
    void *has_mod_method = mono_class_get_method_from_name(mod_loader_class, "HasMod", 1);
    if (!is_loading_field || !has_mod_method) return fail("modloader-status-api", "ModLoader.isLoading/HasMod nao foram encontrados.", 201);

    void *main_vtable_loop = mono_class_vtable ? mono_class_vtable(domain, main_class_startup) : 0;
    void *menu_mode_field = mono_class_get_field_from_name(main_class_startup, "menuMode");
    if (!main_vtable_loop || !menu_mode_field) return fail("main-loop-status-fields", "Main.menuMode nao pode ser lido.", 202);

    void *run_one_frame = 0;
    void *run_search_class = main_class_startup;
    while (run_search_class && !run_one_frame) {
        run_one_frame = mono_class_get_method_from_name(run_search_class, "RunOneFrame", 0);
        run_search_class = mono_class_get_parent(run_search_class);
    }
    if (!run_one_frame) return fail("runoneframe-method", "Microsoft.Xna.Framework.Game.RunOneFrame() nao foi encontrado.", 203);

    typedef void *(*mono_object_unbox_t)(void *);
    mono_object_unbox_t mono_object_unbox = (mono_object_unbox_t)dlsym(mono, "mono_object_unbox");
    if (!mono_object_unbox) return fail("mono-object-unbox-api", "mono_object_unbox nao esta exportado pelo MonoVM.", 204);

    void *split_name_string = mono_string_new(domain, "Split");
    if (!split_name_string) return fail("split-name-string", "nao foi possivel criar string Split.", 205);
    void *has_mod_args[1] = { split_name_string };

    checkpoint("before-startup-managed-profiler-install");
    typedef void *(*mono_profiler_create_t)(void *);
    typedef void (*mono_profiler_set_filter_t)(void *, unsigned int (*)(void *, void *));
    typedef void (*mono_profiler_set_method_cb_t)(void *, void (*)(void *, void *, void *));
    typedef void (*mono_profiler_set_jit_method_cb_t)(void *, void (*)(void *, void *));
    typedef void (*mono_profiler_set_jit_done_cb_t)(void *, void (*)(void *, void *, void *));
    typedef void (*mono_profiler_set_exception_throw_cb_t)(void *, void (*)(void *, void *));
    mono_profiler_create_t mono_profiler_create = (mono_profiler_create_t)dlsym(mono, "mono_profiler_create");
    mono_profiler_set_filter_t mono_profiler_set_filter =
        (mono_profiler_set_filter_t)dlsym(mono, "mono_profiler_set_call_instrumentation_filter_callback");
    mono_profiler_set_method_cb_t mono_profiler_set_enter =
        (mono_profiler_set_method_cb_t)dlsym(mono, "mono_profiler_set_method_enter_callback");
    mono_profiler_set_method_cb_t mono_profiler_set_leave =
        (mono_profiler_set_method_cb_t)dlsym(mono, "mono_profiler_set_method_leave_callback");
    mono_profiler_set_method_cb_t mono_profiler_set_exception_leave =
        (mono_profiler_set_method_cb_t)dlsym(mono, "mono_profiler_set_method_exception_leave_callback");
    mono_profiler_set_jit_method_cb_t mono_profiler_set_jit_begin =
        (mono_profiler_set_jit_method_cb_t)dlsym(mono, "mono_profiler_set_jit_begin_callback");
    mono_profiler_set_jit_method_cb_t mono_profiler_set_jit_failed =
        (mono_profiler_set_jit_method_cb_t)dlsym(mono, "mono_profiler_set_jit_failed_callback");
    mono_profiler_set_jit_done_cb_t mono_profiler_set_jit_done =
        (mono_profiler_set_jit_done_cb_t)dlsym(mono, "mono_profiler_set_jit_done_callback");
    mono_profiler_set_exception_throw_cb_t mono_profiler_set_exception_throw =
        (mono_profiler_set_exception_throw_cb_t)dlsym(mono, "mono_profiler_set_exception_throw_callback");
    if (mono_profiler_create && mono_profiler_set_filter && mono_profiler_set_enter &&
        mono_profiler_set_leave && mono_profiler_set_exception_leave) {
        void *startup_profiler = mono_profiler_create(0);
        if (startup_profiler) {
            mono_profiler_set_filter(startup_profiler, startup_profiler_filter);
            mono_profiler_set_enter(startup_profiler, startup_profiler_enter);
            mono_profiler_set_leave(startup_profiler, startup_profiler_leave);
            mono_profiler_set_exception_leave(startup_profiler, startup_profiler_exception_leave);
            if (mono_profiler_set_exception_throw) mono_profiler_set_exception_throw(startup_profiler, startup_profiler_exception_throw);
            if (mono_profiler_set_jit_begin) mono_profiler_set_jit_begin(startup_profiler, startup_profiler_jit_begin);
            if (mono_profiler_set_jit_failed) mono_profiler_set_jit_failed(startup_profiler, startup_profiler_jit_failed);
            if (mono_profiler_set_jit_done) mono_profiler_set_jit_done(startup_profiler, startup_profiler_jit_done);
            startup_trace_enabled = 1;
            write_text(LOGFILE, "STARTUP_MANAGED_PROFILER=ENABLED large-stack baseline + post-default-texture LoadContent isolation\n");
            write_text(LOGFILE, (mono_profiler_set_jit_begin && mono_profiler_set_jit_failed && mono_profiler_set_jit_done) ? "NPCID_JIT_PROFILER=AVAILABLE\n" : "NPCID_JIT_PROFILER=PARTIAL_OR_UNAVAILABLE\n");
            checkpoint("startup-managed-profiler-ready");
        } else {
            write_text(LOGFILE, "STARTUP_MANAGED_PROFILER=UNAVAILABLE mono_profiler_create returned null; continuing normal startup\n");
            checkpoint("startup-managed-profiler-unavailable");
        }
    } else {
        write_text(LOGFILE, "STARTUP_MANAGED_PROFILER=UNAVAILABLE required Mono profiler exports not present; continuing normal startup\n");
        checkpoint("startup-managed-profiler-unavailable");
    }

    write_text(LOGFILE, "NPC_NETID_MAP_DIAGNOSTIC=-65 -> 235 (Big Hornet Stingy -> Stingy Hornet base); source-backed vanilla NPCID.NetIdMap.\n");
    checkpoint("before-controlled-runoneframe-loop");
    int loader_seen = 0;
    int split_loaded = 0;
    int last_loading = 0;
    int last_menu_mode = -1;
    int completed_frame = 0;
    for (int frame = 1; frame <= 480; frame++) {
        void *frame_exc = 0;
        checkpoint(frame == 1 ? "before-first-runoneframe" : "before-next-runoneframe");
        if (frame == 1) {
            int pre_loading = 0;
            int pre_menu = -1;
            mono_field_static_get_value(mod_loader_vtable, is_loading_field, &pre_loading);
            mono_field_static_get_value(main_vtable_loop, menu_mode_field, &pre_menu);
            char first_frame_state[256];
            snprintf(first_frame_state, sizeof(first_frame_state),
                     "FIRST_FRAME_ENTER\nFIRST_FRAME_STATE isLoading=%d menuMode=%d\nRUNONEFRAME_CALL_ENTER\n",
                     pre_loading, pre_menu);
            write_text(LOGFILE, first_frame_state);
        }
        mono_runtime_invoke(run_one_frame, main_engine_object, 0, &frame_exc);
        if (frame == 1 && !frame_exc) {
            write_text(LOGFILE, "RUNONEFRAME_CALL_EXIT\nFIRST_FRAME_EXIT\n");
            checkpoint("after-first-runoneframe");
        }
        if (frame_exc) {
            char detail[12288];
            char recent_methods[8192];
            if (frame == 1) write_text(LOGFILE, "RUNONEFRAME_EXCEPTION_BEGIN\n");
            exception_full_text(frame_exc, detail, sizeof(detail));
            format_recent_managed_enters(recent_methods, sizeof(recent_methods), 32);
            write_text(LOGFILE, "MANAGED_EXCEPTION_TOSTRING=\n");
            write_text(LOGFILE, detail[0] ? detail : "<sem detalhe>");
            write_text(LOGFILE, "\nLAST_MANAGED_ENTERS_BEGIN\n");
            write_text(LOGFILE, recent_methods);
            write_text(LOGFILE, "LAST_MANAGED_ENTERS_END\n");
            char entity_state[1024];
            snprintf(entity_state, sizeof(entity_state),
                     "CONTENT_SAMPLES_STATE depth=%d npcSeq=%d npcId=%d npcDepth=%d projectileSeq=%d projectileId=%d projectileDepth=%d itemSeq=%d itemId=%d itemDepth=%d\n",
                     content_samples_depth,
                     npc_setdefaults_top_seq, npc_setdefaults_current_id, npc_setdefaults_depth,
                     projectile_setdefaults_top_seq, projectile_setdefaults_current_id, projectile_setdefaults_depth,
                     item_setdefaults_top_seq, item_setdefaults_current_id, item_setdefaults_depth);
            write_text(LOGFILE, entity_state);

            char static_audit[8192];
            static_audit[0] = 0;
            void *npcid_outer = mono_class_from_name(tml_img, "Terraria.ID", "NPCID");
            void *npcid_sets = 0;
            if (npcid_outer && mono_class_get_nested_types) {
                void *nested_iter = 0;
                void *nested = 0;
                while ((nested = mono_class_get_nested_types(npcid_outer, &nested_iter)) != 0) {
                    const char *nested_name = g_class_name ? g_class_name(nested) : 0;
                    if (nested_name && !strcmp(nested_name, "Sets")) {
                        npcid_sets = nested;
                        break;
                    }
                }
            }
            write_text(LOGFILE, "NPCID_SETS_AUDIT_BEGIN\n");
            append_static_field_status(domain, npcid_outer, "Search", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "Factory", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "SpecialSpawningRules", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "NPCPortraits", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "NPCBestiaryDrawOffset", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "DebuffImmunitySets", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "SpawnOnPlayerCanSpawnInMidairOnSkyblock", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "ShimmerImmunity", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "ImmuneToWhipTags", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "ImmuneToRegularBuffs", static_audit, sizeof(static_audit));
            append_static_field_status(domain, npcid_sets, "SpecificDebuffImmunity", static_audit, sizeof(static_audit));
            void *setfactory_class = mono_class_from_name(tml_img, "Terraria.ID", "SetFactory");
            append_static_field_status(domain, setfactory_class, "SetFactories", static_audit, sizeof(static_audit));
            write_text(LOGFILE, static_audit[0] ? static_audit : "<audit unavailable>\n");
            write_text(LOGFILE, "NPCID_SETS_AUDIT_END\n");

            write_state_line("RUNONEFRAME_EXCEPTION", "RunOneFrame", -1, 0);
            if (frame == 1) write_text(LOGFILE, "RUNONEFRAME_EXCEPTION_END\nFIRST_FRAME_EXIT\n");
            int loading_now = 0;
            mono_field_static_get_value(mod_loader_vtable, is_loading_field, &loading_now);
            int menu_now = -1;
            mono_field_static_get_value(main_vtable_loop, menu_mode_field, &menu_now);
            snprintf(report, sizeof(report),
                "MonoVM Phase 2.22.98 - Post-Texture LoadContent Isolation\n\n"
                "Pre-Run sequence: OK\n"
                "RunOneFrame #%d: MANAGED EXCEPTION\n"
                "ModLoader.isLoading: %s\nMain.menuMode: %d\n"
                "Exception.ToString(): %s\n"
                "Entity state: NPC seq=%d id=%d depth=%d | Projectile seq=%d id=%d depth=%d | Item seq=%d id=%d depth=%d\n"
                "NPCID.Sets progress: cctorActive=%d cctorCompleted=%d dictionaryAdds=%d listAdds=%d\n"
                "Last managed entries:\n%s"
                "Assembly preload requests: %s\nPreload hook calls: %d\n\n"
                "Resultado: o .tmod ja esta na pasta Mods real e habilitado. A falha ocorreu durante o primeiro loop normal do jogo/loader, nao no probe manual de assembly.\n",
                frame, loading_now ? "TRUE" : "FALSE", menu_now,
                detail[0] ? detail : "<sem detalhe>",
                npc_setdefaults_top_seq, npc_setdefaults_current_id, npc_setdefaults_depth,
                projectile_setdefaults_top_seq, projectile_setdefaults_current_id, projectile_setdefaults_depth,
                item_setdefaults_top_seq, item_setdefaults_current_id, item_setdefaults_depth,
                npcid_sets_cctor_active, npcid_sets_cctor_completed, npc65_dictionary_adds, npc65_list_adds,
                recent_methods,
                requested_assemblies[0] ? requested_assemblies : "<none>", preload_calls);
            write_text(LOGFILE, report);
            SDL_ShowSimpleMessageBox(0x40, "tML Android MonoVM - Phase 2.22.87", report, 0);
            return 206;
        }

        int loading_now = 0;
        mono_field_static_get_value(mod_loader_vtable, is_loading_field, &loading_now);
        if (loading_now && !loader_seen) {
            loader_seen = 1;
            checkpoint("normal-modloader-background-load-started");
        }
        last_loading = loading_now;

        int menu_now = -1;
        mono_field_static_get_value(main_vtable_loop, menu_mode_field, &menu_now);
        last_menu_mode = menu_now;

        void *has_exc = 0;
        void *has_result = mono_runtime_invoke(has_mod_method, 0, has_mod_args, &has_exc);
        if (!has_exc && has_result) {
            unsigned char *boxed_bool = (unsigned char *)mono_object_unbox(has_result);
            if (boxed_bool && *boxed_bool) split_loaded = 1;
        }

        if (frame == 1) checkpoint("game-first-frame-ok");
        if (split_loaded && !loading_now && menu_now == 0) {
            completed_frame = frame;
            checkpoint("normal-tmod-loader-split-loaded");
            break;
        }

        if ((frame % 60) == 0) {
            char state_line[256];
            snprintf(state_line, sizeof(state_line),
                "FRAME_STATUS frame=%d isLoading=%d menuMode=%d hasSplit=%d\n",
                frame, loading_now, menu_now, split_loaded);
            write_text(LOGFILE, state_line);
        }
    }

    if (completed_frame > 0) {
        snprintf(report, sizeof(report),
            "MonoVM Phase 2.22.86 OK - Normal tModLoader .tmod Startup Pipeline\n\n"
            "EngineInit: OK\n"
            "Terraria.Main constructor: OK\n"
            "Legacy localization: OK\n"
            "SocialMode.None Android backend: OK\n"
            "LaunchInitializer.LoadParameters: OK\n"
            "Game.RunOneFrame controlled loop: OK\n"
            "Normal ModLoader background load observed: %s\n"
            "Split discovered/loaded from Main.SavePath/Mods: YES\n"
            "ModLoader.isLoading after load: FALSE\n"
            "Main.menuMode after load: 0\n"
            "Completion frame: %d\n\n"
            "Resultado: o Split.tmod foi carregado pelo fluxo normal de startup do tModLoader a partir da pasta Mods/enabled.json. BootstrapFix18.11 nao abriu TmodFile, nao criou ModLoadContext e nao chamou Split.Load manualmente.\n"
            "Este e o primeiro teste do pipeline normal completo controlado pelo menu/ModLoader do jogo.\n\n"
            "Runtime: 8.0.23\nRID: android-arm64\n",
            loader_seen ? "YES" : "COMPLETED BETWEEN SAMPLES",
            completed_frame);
        write_text(LOGFILE, report);
        SDL_ShowSimpleMessageBox(0x40, "tML Android MonoVM - Phase 2.22.87", report, 0);
        return 0;
    }

    snprintf(report, sizeof(report),
        "MonoVM Phase 2.22.98 - Post-Texture LoadContent Isolation Timeout\n\n"
        "Pre-Run sequence: OK\nGame.RunOneFrame: 480 frames completed\n"
        "Loader observed active: %s\n"
        "Split present in ModLoader.HasMod: %s\n"
        "Final ModLoader.isLoading: %s\n"
        "Final Main.menuMode: %d\n\n"
        "O processo nao encontrou uma excecao gerenciada, mas o carregamento normal nao concluiu dentro da janela controlada.\n"
        "Runtime: 8.0.23\nRID: android-arm64\n",
        loader_seen ? "YES" : "NO",
        split_loaded ? "YES" : "NO",
        last_loading ? "TRUE" : "FALSE",
        last_menu_mode);
    write_text(LOGFILE, report);
    SDL_ShowSimpleMessageBox(0x40, "tML Android MonoVM - Phase 2.22.87", report, 0);
    return 207;
}

struct phase2_22_90_thread_args {
    int argc;
    char **argv;
    int result;
};

static void *phase2_22_90_large_stack_entry(void *opaque) {
    struct phase2_22_90_thread_args *args = (struct phase2_22_90_thread_args *)opaque;
    write_text(STACKFILE, "WORKER_ENTER stackBytes=33554432\n");
    args->result = phase2_22_90_main_impl(args->argc, args->argv);
    char line[128];
    snprintf(line, sizeof(line), "WORKER_EXIT result=%d\n", args->result);
    write_text(STACKFILE, line);
    return 0;
}

int SDL_main(int argc, char **argv) {
    mkdir(BASE, 0770);
    if (file_exists(STACKFILE)) remove(STACKFILE);
    if (file_exists(DISPLAYFILE)) remove(DISPLAYFILE);
    write_text(STACKFILE, "PHASE=2.22.98\nLARGE_STACK_REQUEST bytes=33554432\n");

    unsigned char attr_storage[128] __attribute__((aligned(16)));
    memset(attr_storage, 0, sizeof(attr_storage));
    int rc_init = pthread_attr_init(attr_storage);
    char line[256];
    snprintf(line, sizeof(line), "PTHREAD_ATTR_INIT rc=%d\n", rc_init);
    write_text(STACKFILE, line);
    if (rc_init != 0) {
        write_text(STACKFILE, "LARGE_STACK_FALLBACK reason=attr_init\n");
        return phase2_22_90_main_impl(argc, argv);
    }

    int rc_stack = pthread_attr_setstacksize(attr_storage, (size_t)(32UL * 1024UL * 1024UL));
    snprintf(line, sizeof(line), "PTHREAD_ATTR_SETSTACKSIZE rc=%d requested=33554432\n", rc_stack);
    write_text(STACKFILE, line);
    if (rc_stack != 0) {
        pthread_attr_destroy(attr_storage);
        write_text(STACKFILE, "LARGE_STACK_FALLBACK reason=setstacksize\n");
        return phase2_22_90_main_impl(argc, argv);
    }

    struct phase2_22_90_thread_args args;
    args.argc = argc;
    args.argv = argv;
    args.result = 255;
    unsigned long thread = 0;
    int rc_create = pthread_create(&thread, attr_storage, phase2_22_90_large_stack_entry, &args);
    pthread_attr_destroy(attr_storage);
    snprintf(line, sizeof(line), "PTHREAD_CREATE rc=%d\n", rc_create);
    write_text(STACKFILE, line);
    if (rc_create != 0) {
        write_text(STACKFILE, "LARGE_STACK_FALLBACK reason=pthread_create\n");
        return phase2_22_90_main_impl(argc, argv);
    }

    void *thread_result = 0;
    int rc_join = pthread_join(thread, &thread_result);
    snprintf(line, sizeof(line), "PTHREAD_JOIN rc=%d workerResult=%d\n", rc_join, args.result);
    write_text(STACKFILE, line);
    if (rc_join != 0)
        return 254;
    return args.result;
}

